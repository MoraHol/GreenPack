-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: sotechco_greenpack
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about`
--

DROP TABLE IF EXISTS `about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `about` (
  `id_about` int(11) NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8_spanish_ci NOT NULL,
  `content` text COLLATE utf8_spanish_ci NOT NULL,
  `image` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_about`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about`
--

LOCK TABLES `about` WRITE;
/*!40000 ALTER TABLE `about` DISABLE KEYS */;
INSERT INTO `about` (`id_about`, `title`, `content`, `image`) VALUES (1,'EL AMOR DE GREENPACK HACIA EL MEDIO AMBIENTE','<p class=\"f24 normal\">Nuestro esp&iacute;ritu protector del medio ambiente nos permiti&oacute; destacarnos en el mercado por ser los primeros en traer al pa&iacute;s materias primas totalmente biodegradables para transformarlos en grandiosos empaques. Materias primas como papeles v&iacute;rgenes de fibras largas (sustituto de los reciclados en empaques primarios), papeles antigrasa (sustituto de los parafinados) y Biopol&iacute;meros (sustituto de los pl&aacute;sticos a base de petr&oacute;leo) para laminaci&oacute;n y ventanillas. Todas las materias primas tienen certificaciones no solo ambientales sino aptas para entrar en contacto directo con alimentos (Empaque primario).</p><p class=\"f24 normal\">Hemos registrado como marcas EMPAQUES VERDES (la traducci&oacute;n de nuestro nombre) y GREENBAGS, una nueva l&iacute;nea de productos con materiales laminados a base de ma&iacute;z; totalmente biodegradables, especiales para empaques de caf&eacute; y productos org&aacute;nicos, creando la oportunidad para que estos productos tengan los mejores empaques.</p><p class=\"text-center\"><img src=\"/images/greenbags_logo_verde.png\" alt=\"\" width=\"150\" class=\"fr-fic fr-dii\"><img src=\"/images/greenpack_logo_verde.png\" alt=\"\" width=\"150\" class=\"fr-fic fr-dii\"> <img src=\"/images/empaques_verdes_logo_verde.png\" alt=\"\" width=\"150\" class=\"fr-fic fr-dii\"></p><p><br></p>','/images/sea.jpg'),(2,'NUESTRO COMPROMISO','Nuestros empaques desentonan naturalmente, se han actualizado en todas las áreas requeridas para manejar un beneficio fenomenal.\r\n\r\nCon el fin de ayudar a nuestro planeta tierra y a nuestra salud, hemos implementado el mejoramiento continuo, capacitado a nuestro más valioso talento humano, disminuido la reducción de desperdicios, he implementado políticas de responsabilidad social y ambiental. Somos un medio de concientización y difusión de las prácticas a seguir.','/images/AdobeStock_256856590_Preview.jpeg'),(3,'QUIENES SOMOS','GREENPACK es una empresa innovadora que nació para actuar y guiar a un mercado que necesita un cambio. Hoy en día, gracias a la normativa que protege al medioambiente, nuestra conciencia de seguir por un camino verde que no se detiene y la conciencia de cambio que se ha generado alrededor del mundo, Green pack ha logrado posicionarse y obtener un completo reconocimiento del mercado como transformador e innovador en soluciones de empaques biodegradables.\r\n\r\nDentro de nuestro catálogo de productos; ofrecemos una amplia variedad de Bolsas, Cajas y Soportes, Sacos Industriales y empaques agroindustriales, láminas y etiquetas, todos ellos con la más alta calidad.\r\n\r\nEn el año 2015 cumplimos 10 años ejecutando y renovando nuestra visión generada en el 2006: Ser reconocida en Colombia como la primera elección del mercado de empaques biodegradables.\r\n\r\nContamos con los mejores clientes de Colombia y exportamos a varios países de América y Europa.','https://greenpack.com.co/wp-content/uploads/2017/07/bg-nuestra-empresa.jpg');
/*!40000 ALTER TABLE `about` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id_admins` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  `last_name` varchar(64) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(512) COLLATE utf8_spanish_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `id_role` int(11) NOT NULL,
  `password` varchar(257) COLLATE utf8_spanish_ci NOT NULL,
  `token_password` varchar(512) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_admins`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_admins_roles_admin` (`id_role`),
  CONSTRAINT `fk_admins_roles_admin` FOREIGN KEY (`id_role`) REFERENCES `roles_admin` (`id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` (`id_admins`, `name`, `last_name`, `email`, `phone`, `id_role`, `password`, `token_password`) VALUES (4,'Alexis ','Holguin','alex.holguin@teenus.com.co','',2,'895d196a3ec8b67ff75fb6bd278bcef9c992838f0e67fd999460721800988918','as'),(5,'Sergio Eduardo','Velandia Obando','sergio.velandia@teenus.com.co','3175125191',2,'e77cb994418f5bc0ec1007b6c137918d9aed4e7b0bde45d74a50d09272c2d602','5c6d9fd0c09ef7dd0ec8859cf31da9407067736de43cc25cc9df5c1595c1ea4889944eb25e9d8032dc07370de962e8e9974c3b3909d41382c7d7710e59a64b8b41d0594929e3a3ae82c94dc95404a03fc19de40d59692f1bb553316ca10738734a4ae4d1ed0a40f71287c606a7d82be811d62fff558bf064928d29a875a3329de17dbe1bcf807fbb5340f80f2fb66edd75cf51d1b4874df47d0f8a0522547207dada16e34bd670c435cf80101317501d54914be71afe174bf925a605593efc7bcabeedd67a91356e92070a3de881f36c0356e9ccedace516c0b08bbcea5aaf5bd2ab254faf8dc54a464c5afdcde7c81cee93e407915f2c058ecf3a4513af625c'),(6,'martha','olmos','martha.olmos@teenus.com.co','',2,'fb4db363ff68c72fede366b5c92ecaeb23a770b9fbd41ef5b8cb0413e3fc7f1d','1d48ba9e451ae8934c86f7d80de936ff161af596cd47593a7e5d74c4821d7daf534e44b27cdd985349470bf94aebcd46e20be71078936cdadb7e839092e3aa7a742133887a9831e51a9a36b272328ae23a566614518fd66179688876790f13981e86df6ed2225a4d08d6661865681ea9a34bd130ebc8214833f445068e11847a70fefacabc684f217415abd82332ef0358b5b37552382af2b7058496b65780aad3f8fe986173db82ce756fb151c994ca9c3e03675e300850f7e523477226db747bd7c4d3e66550e976a694c938e39a97f26bf08f79b6fb5492a060318e21eb8b60e812c93f960365d3d53cf8b6d156784439f7e9b9ebcf8ff1aa5f9ada01ab23'),(7,'Julio ','Contreras','sergio.velandia@gmail.com','',1,'fecb1958c276821ca5c1b87e84a8c82aee55dcc02bec61b44ab33b6824be941a','98c9d36e5a7227a47b9151b30b3cc82fc113118ff3998e704dafbd9bef6c0fead9b894bbfb28e0cffbf9759742bd28f82130f283a46c5929566a3971946acbb8ed2f44b539a670322a531043bfc28d47216c4cce3e1aad3ce6ca01ac68d793e9d100d3681885657b19df4827d0b5612286da45675713fc28da1b76b06e523ebb0c2bdc9719fa6b97f294e07bc893939dd2cf7d0632b084f2c5d19ec2d9c8ed693b14fae873704b95f3bbc36808b08bb1820b3507c31c7f7b4adeeac2795c8cea05d06ac814bae7f98f56a1aca9bc2862c47efb45e2fd77d0aa47df9c0635267d6d19752a0c87341fceef1b0b7a2eb2faccf9c84ce1fc0cd0e0f34d8d76f5b892'),(27,'Endorfinate','SASA','sergio.velandia@hotmail.com','',1,'e77cb994418f5bc0ec1007b6c137918d9aed4e7b0bde45d74a50d09272c2d602','23eaf303809b61f5ea3a53c15ce546bcd556e5e755fe501765df1420f768cc49cc6700428ea342e6b27741081e8c8f366354c150a65f8fef223c968f396b47b7e6e4f00bc1c9c341a5b4cfb39adae21e3cd78a9fed226a63d2e8857b043b62a64caa15bcd7afdedc8dd42bc7b1d9659c1e76c8bb56b796b960939e0b0c30d5da923a21a1973b310697f214f8d391c8739161d761c5b598c8ffae7ba9eb9c948f207e9515f9765d1fe725d69cd4110261fbc67af9df0537036ecf0ae9f0174426dfb31d9934b8e06f1cfecb5fa03e9c196f6d2f518529141d7369daafeabd58cd3f4bc6714773f6d337867f7b87873328dcad2dd7ff88f9de831c390f281dd60a');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assignment_queue`
--

DROP TABLE IF EXISTS `assignment_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignment_queue` (
  `id_admin` int(11) NOT NULL,
  KEY `fk_assignment_queue_admin` (`id_admin`),
  CONSTRAINT `fk_assignment_queue_admin` FOREIGN KEY (`id_admin`) REFERENCES `admins` (`id_admins`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assignment_queue`
--

LOCK TABLES `assignment_queue` WRITE;
/*!40000 ALTER TABLE `assignment_queue` DISABLE KEYS */;
INSERT INTO `assignment_queue` (`id_admin`) VALUES (7);
/*!40000 ALTER TABLE `assignment_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banner_shop`
--

DROP TABLE IF EXISTS `banner_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banner_shop` (
  `id_banner_shop` int(11) NOT NULL AUTO_INCREMENT,
  `color` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `background_color` varchar(10) COLLATE utf8_spanish_ci NOT NULL,
  `title` text COLLATE utf8_spanish_ci NOT NULL,
  `subtitle` text COLLATE utf8_spanish_ci NOT NULL,
  `image` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_banner_shop`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner_shop`
--

LOCK TABLES `banner_shop` WRITE;
/*!40000 ALTER TABLE `banner_shop` DISABLE KEYS */;
INSERT INTO `banner_shop` (`id_banner_shop`, `color`, `background_color`, `title`, `subtitle`, `image`) VALUES (1,'#82187c','#ffffff','Tu alimentos 100% perdurables','En bolsas, cajas y laminas 100% naturales y biodegradables','https://en.teenus.com.co/upload/img/IMG-1566503916-5d5ef3ecc30d3.jpeg');
/*!40000 ALTER TABLE `banner_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carousel_clients`
--

DROP TABLE IF EXISTS `carousel_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carousel_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_url` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carousel_clients`
--

LOCK TABLES `carousel_clients` WRITE;
/*!40000 ALTER TABLE `carousel_clients` DISABLE KEYS */;
INSERT INTO `carousel_clients` (`id`, `image_url`) VALUES (24,'https://en.teenus.com.co/upload/img/IMG-1565714205-5d52e71d24000.png'),(25,'https://en.teenus.com.co/upload/img/IMG-1565714205-5d52e71d80e13.png'),(26,'https://en.teenus.com.co/upload/img/IMG-1565714206-5d52e71e21a25.png'),(27,'https://en.teenus.com.co/upload/img/IMG-1565714206-5d52e71e99dcf.png'),(28,'https://en.teenus.com.co/upload/img/IMG-1565714207-5d52e71f171c6.png'),(29,'https://en.teenus.com.co/upload/img/IMG-1565714207-5d52e71f87d91.png'),(30,'https://en.teenus.com.co/upload/img/IMG-1565714208-5d52e72017299.png'),(31,'https://en.teenus.com.co/upload/img/IMG-1566318454-5d5c1f76b52aa.png');
/*!40000 ALTER TABLE `carousel_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id_categories` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `parent_category` int(11) DEFAULT NULL,
  `description` text NOT NULL,
  `image` text NOT NULL,
  PRIMARY KEY (`id_categories`),
  KEY `fk_categories_categories1_idx` (`parent_category`),
  CONSTRAINT `fk_categories_categories1` FOREIGN KEY (`parent_category`) REFERENCES `categories` (`id_categories`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id_categories`, `name`, `parent_category`, `description`, `image`) VALUES (1,'bolsas',NULL,'¿Te gustaría proteger el medio ambiente junto a nosotros?','/images/categories/bolsas_biodegradables.png'),(2,'cajas',NULL,'Productos hechos 100% con amor','/images/categories/cajas_biodegradables.png'),(3,'exhibir',2,'Exhibe tus productos al mismo tiempo que protegemos nuestra naturaleza','/images/categories/cajas_biodegradables.png'),(4,'llevar',2,'Nunca había sido mas fácil cargar nuestros productos','/images/categories/cajas_biodegradables.png'),(5,'servir',2,'','/images/categories/cajas_biodegradables.png'),(6,'laminas',NULL,'Productos de un solo uso que cuidan 100% nuestro medio ambiente','/images/categories/laminas_biodegradables.png'),(7,'productos especiales',NULL,'','/images/categories/Rollo_de_papel.png'),(8,'Bolsas Laminadas',1,'as',''),(9,'Manijas y Vasos',NULL,'',''),(11,'Etiquetas y Separadores',NULL,'',''),(12,'Piñateria',NULL,'',''),(13,'Sobres y Carpetas',NULL,'','');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id_clients` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `name_company` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_clients`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` (`id_clients`, `name`, `surname`, `email`, `name_company`) VALUES (1,'William Alexis','Holguin Mora','wholguinmor@uniminuto.edu.co',''),(2,'','','','');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `materials` (
  `id_materials` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `grammage` int(11) NOT NULL,
  `price_per_kg` bigint(20) NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_spanish_ci,
  `price_5400` bigint(20) DEFAULT NULL,
  `price_7000` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id_materials`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materials`
--

LOCK TABLES `materials` WRITE;
/*!40000 ALTER TABLE `materials` DISABLE KEYS */;
INSERT INTO `materials` (`id_materials`, `name`, `grammage`, `price_per_kg`, `description`, `price_5400`, `price_7000`) VALUES (2,'MG Blanco',40,3500,'Papel hecho a partir de la combinación de fibras vírgenes. Diseñado para impresión de alta calidad que exige una superficie lisa.',0,0),(7,'Fine Kraft',40,4600,'Papel especial de bajo gramaje para el contacto con alimentos. De fácil reciclado que permite la adición de ventanillas mucho más fácil con PLA (plástico ácido poliláctico). Tiene unas representativas rayas verticales que le dan un toque especial al empaque. Permite una impresión de alta definición y claridad que dan un acabado perfecto para regalos y empaques de alimentos. ',NULL,NULL),(8,'Bond',60,2000,'Fabricado 100% con fibras de eucalipto blanqueadas con propiedades muy buenas como: resistencia, superficie y composición. Podemos encontrarlo de colores, normalmente es blanco. Con gramajes entre 60 y 115gr/m², lo que lo hace más resistente.',NULL,NULL),(9,'PLA',30,18000,'El ácido poliláctico o poliácido láctico (PLA) es un polímero constituido por moléculas de ácido láctico, con propiedades semejantes a las del tereftalato de polietileno (PET) que se utiliza para hacer envases, pero que además es biodegradable. Se degrada fácilmente en agua y óxido de carbono.',NULL,NULL),(10,'MG Natural',40,3400,'Papel hecho a partir de la combinación de fibras vírgenes. Diseñado para alta calidad de impresión y fabricación que exige una superficie lisa.',NULL,NULL),(11,'Antigrasa',40,7500,'Papel con una alta resistencia a la humedad, aceites y grasas. Habitualmente el papel base es un monolúcido (MG).  Aunque depende de la calidad del papel y su tratamiento, responde en buena forma a la impresión.',NULL,NULL),(12,'Encerado',40,3250,'Papel de seda con triple encerado. Hecho con cera de parafina inocua que se inyecta en los poros del papel y se esparce sobre la parte exterior como capa protectora. El papel de cera y el papel de pergamino pueden ser usados para delinear los moldes de hornear bizcochos. Puede ser usado en el horno microondas.',NULL,NULL),(13,'FINEKRAFT 60 GR',60,4500,'',NULL,NULL),(14,'FINEKRAFT 85 GR',85,4500,'',NULL,NULL),(15,'FINEKRAFT 120 GR',120,4500,'',NULL,NULL),(16,'BOND 60 GR',60,3450,'',NULL,NULL),(17,'BOND 90 GR',90,3450,'',NULL,NULL),(18,'BOND 115 GR',115,3450,'',NULL,NULL),(19,'EARTHPACT 50 GR',50,3450,'',NULL,NULL),(20,'EARTHPACT 60 GR',60,3450,'',NULL,NULL),(21,'EARTHPACT 90 GR',90,3450,'',NULL,NULL),(22,'EARTHPACT 150 GR',150,3450,'',NULL,NULL),(23,'ANTIGRASA',40,7500,'',NULL,NULL),(24,'Kraft 40 GR',40,5000,'',NULL,NULL),(25,'Kraft 60 GR',60,5000,'',NULL,NULL),(26,'CAÑA 40 GR',40,3450,'',NULL,NULL),(27,'CAÑA 60 GR',60,3450,'',NULL,NULL),(28,'KRAFT IMPORTADO 50 GR',50,4500,'',NULL,NULL),(29,'KRAFT IMPORTADO 60GR',60,4500,'',NULL,NULL),(31,'KRAFT + PLA',100,494,'',494,851),(32,'KRAFT + ECOVIO',90,386,'',386,501),(33,'KRAFT + PLA + ECOVIO',120,710,'',710,1131),(34,'KRAFT + PLA METALIZADO + ECOVIO',125,859,'',859,1113),(35,'KRAFT + CELOFAN + ECOVIO',150,872,'',872,1131),(36,'KRAFT + PLA METALIZADO + ECOVIO + CELOFAN',155,1345,'',1345,1743),(37,'CAÑA + PLA',100,454,'',454,760),(38,'CAÑA + ECOVIO',90,346,'',346,410),(39,'CAÑA + PLA + ECOVIO',120,670,'',670,1040),(40,'CAÑA + PLA METALIZADO + ECOVIO',125,819,'',819,1023),(41,'CAÑA + CELOFAN + ECOVIO',150,832,'',832,1040),(42,'CAÑA + PLA METALIZADO + ECOVIO + CELOFAN',155,1305,'',1305,1653),(43,'KRAFT 170 GR',170,4000,'',NULL,NULL),(44,'CAÑA 60*90',60,550,'',NULL,NULL),(45,'CAÑA LAMINADO 60*90',60,874,'',NULL,NULL),(46,'CAÑA 70*100',60,750,'',NULL,NULL),(47,'CAÑA LAMINADO 70*100',60,1170,'',NULL,NULL);
/*!40000 ALTER TABLE `materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `measurements`
--

DROP TABLE IF EXISTS `measurements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `measurements` (
  `id_measurements` int(11) NOT NULL AUTO_INCREMENT,
  `width` varchar(45) DEFAULT NULL,
  `height` varchar(45) DEFAULT NULL,
  `lenght` varchar(45) DEFAULT NULL,
  `window` int(11) NOT NULL,
  `products_id_products` int(11) NOT NULL,
  `id_material` int(11) DEFAULT NULL,
  `pliego` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id_measurements`,`products_id_products`),
  UNIQUE KEY `width` (`width`,`height`,`lenght`,`products_id_products`,`id_material`) USING BTREE,
  KEY `fk_measurements_products1_idx` (`products_id_products`),
  KEY `fk_measurements_materials` (`id_material`),
  CONSTRAINT `fk_measurements_products1` FOREIGN KEY (`products_id_products`) REFERENCES `products` (`id_products`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=1412 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measurements`
--

LOCK TABLES `measurements` WRITE;
/*!40000 ALTER TABLE `measurements` DISABLE KEYS */;
INSERT INTO `measurements` (`id_measurements`, `width`, `height`, `lenght`, `window`, `products_id_products`, `id_material`, `pliego`) VALUES (22,'15','9','38',0,5,14,NULL),(23,'19','10','38',0,5,14,NULL),(24,'19','12','38',0,5,14,NULL),(25,'21','13','38',0,5,14,NULL),(26,'21','15','38',0,5,14,NULL),(27,'22','12','38',0,5,14,NULL),(28,'22','15','46',0,5,14,NULL),(29,'25','14','46',0,5,14,NULL),(30,'25','16','46',0,5,14,NULL),(31,'27','17','46',0,5,14,NULL),(32,'30','16,5','46',0,5,14,NULL),(33,'30','18','46',0,5,14,NULL),(34,'30','20','46',0,5,14,NULL),(35,'32','18','46',0,5,14,NULL),(36,'32','22','46',0,5,14,NULL),(37,'12','9','38',0,5,15,NULL),(48,'30','16,5','46',0,5,15,NULL),(54,'15','9','38',0,5,15,NULL),(55,'19','10','38',0,5,15,NULL),(56,'19','12','38',0,5,15,NULL),(57,'21','13','38',0,5,15,NULL),(58,'21','15','38',0,5,15,NULL),(59,'22','12','38',0,5,15,NULL),(60,'22','15','46',0,5,15,NULL),(61,'25','14','46',0,5,15,NULL),(62,'25','16','46',0,5,15,NULL),(63,'27','17','46',0,5,15,NULL),(64,'30','16.5','46',0,5,15,NULL),(65,'30','18','46',0,5,15,NULL),(66,'30','20','46',0,5,15,NULL),(67,'32','18','46',0,5,15,NULL),(68,'32','22','46',0,5,15,NULL),(69,'12','9','38',0,5,16,NULL),(70,'15','9','38',0,5,16,NULL),(71,'19','10','38',0,5,16,NULL),(72,'19','12','38',0,5,16,NULL),(73,'21','13','38',0,5,16,NULL),(74,'21','15','38',0,5,16,NULL),(75,'12','9','38',0,5,17,NULL),(76,'15','9','38',0,5,17,NULL),(77,'19','10','38',0,5,17,NULL),(78,'19','12','38',0,5,17,NULL),(79,'21','13','38',0,5,17,NULL),(80,'21','15','38',0,5,17,NULL),(81,'22','12','38',0,5,17,NULL),(82,'22','15','46',0,5,17,NULL),(83,'25','14','46',0,5,17,NULL),(84,'25','16','46',0,5,17,NULL),(85,'22','12','38',0,5,18,NULL),(86,'22','15','46',0,5,18,NULL),(87,'25','14','46',0,5,18,NULL),(88,'25','16','46',0,5,18,NULL),(89,'27','17','46',0,5,18,NULL),(90,'30','16,5','46',0,5,18,NULL),(91,'30','18','46',0,5,18,NULL),(92,'30','20','46',0,5,18,NULL),(93,'32','18','46',0,5,18,NULL),(94,'32','22','46',0,5,18,NULL),(95,'12','9','38',0,5,19,NULL),(96,'15','9','38',0,5,19,NULL),(97,'19','10','38',0,5,19,NULL),(98,'19','12','38',0,5,19,NULL),(99,'21','13','38',0,5,19,NULL),(100,'21','15','38',0,5,19,NULL),(101,'22','12','38',0,5,19,NULL),(102,'22','15','46',0,5,19,NULL),(103,'25','14','46',0,5,19,NULL),(104,'12','9','38',0,5,20,NULL),(105,'15','9','38',0,5,20,NULL),(106,'19','10','38',0,5,20,NULL),(107,'19','12','38',0,5,20,NULL),(108,'21','13','38',0,5,20,NULL),(109,'21','15','38',0,5,20,NULL),(110,'22','12','38',0,5,20,NULL),(111,'22','15','46',0,5,20,NULL),(112,'25','14','46',0,5,20,NULL),(113,'12','9','38',0,5,21,NULL),(114,'15','9','38',0,5,21,NULL),(115,'19','10','38',0,5,21,NULL),(116,'19','12','38',0,5,21,NULL),(117,'21','13','38',0,5,21,NULL),(118,'21','15','38',0,5,21,NULL),(119,'22','12','38',0,5,21,NULL),(120,'22','15','46',0,5,21,NULL),(121,'25','14','46',0,5,21,NULL),(122,'25','16','46',0,5,22,NULL),(123,'27','17','46',0,5,22,NULL),(124,'30','16,5','46',0,5,22,NULL),(125,'30','18','46',0,5,22,NULL),(126,'30','20','46',0,5,22,NULL),(127,'32','18','46',0,5,22,NULL),(128,'32','22','46',0,5,22,NULL),(129,'12','9','38',0,5,23,NULL),(130,'15','9','38',0,5,23,NULL),(131,'19','10','38',0,5,23,NULL),(132,'20','20','0',0,11,NULL,NULL),(133,'25','25','0',0,11,NULL,NULL),(134,'30','30','0',0,11,NULL,NULL),(135,'35','35','0',0,11,NULL,NULL),(136,'40','40','0',0,11,NULL,NULL),(137,'45','45','0',0,11,NULL,NULL),(138,'50','50','0',0,11,NULL,NULL),(139,'60','40','0',0,11,NULL,NULL),(140,'20','20','0',0,12,NULL,NULL),(141,'25','25','0',0,12,NULL,NULL),(142,'30','30','0',0,12,NULL,NULL),(143,'35','35','0',0,12,NULL,NULL),(144,'40','40','0',0,12,NULL,NULL),(145,'45','45','0',0,12,NULL,NULL),(146,'50','50','0',0,12,NULL,NULL),(147,'60','40','0',0,12,NULL,NULL),(148,'10','10','0',0,13,NULL,NULL),(149,'12','12','0',0,13,NULL,NULL),(150,'14','14','0',0,13,NULL,NULL),(151,'8','16.6','6',8,14,NULL,5400),(152,'14.5','27','8.5',4,14,NULL,7000),(153,'9','21.9','3',8,14,NULL,7000),(154,'21','25.5','7',6,14,NULL,7000),(155,'12','23.5','7',4,14,NULL,5400),(156,'11.5','27','6.5',4,14,NULL,5400),(157,'9,7','24','7.5',8,14,NULL,7000),(158,'28','35','6.5',2,14,NULL,5400),(159,'2.8','27.7','3.2',6,14,NULL,7000),(160,'13','33.5','7',2,15,NULL,5400),(161,'11','32.9','4.5',2,15,NULL,5400),(162,'6.7','18','4',8,16,NULL,5400),(163,'6.5','18','2',10,16,NULL,5400),(164,'11','25','3.5',4,16,NULL,5400),(165,'18','28','3.2',3,16,NULL,7000),(166,'14','33','5.5',2,16,NULL,5400),(167,'6.4','18','1.7',10,16,NULL,5400),(168,'12.5','25','4.5',4,16,NULL,7000),(169,'11','25','3.5',4,17,NULL,5400),(170,'8','8','1',32,18,NULL,7000),(171,'10','13.5','5.5',18,19,NULL,7000),(172,'9','13.5','4',12,19,NULL,7000),(173,'16','26','4.5',6,19,NULL,7000),(174,'16','26','4.5',6,19,NULL,7000),(175,'13','22','3.2',6,19,NULL,5400),(176,'16','28','4',4,19,NULL,7000),(177,'11','14','5',16,19,NULL,7000),(178,'7','12','3.5',24,19,NULL,7000),(179,'10','21','6',12,19,NULL,7000),(180,'12','18','3',8,19,NULL,5400),(181,'13','18','6',8,19,NULL,5400),(182,'14','21','3.5',8,19,NULL,7000),(183,'10','13.5','5.5',18,19,NULL,7000),(184,'16','24','3.6',6,19,NULL,7000),(185,'18','26.6','2',4,19,NULL,7000),(186,'12','18','3',8,20,NULL,7000),(187,'16.4','29.2','3.7',4,20,NULL,7000),(188,'15.4','23','3.5',6,20,NULL,7000),(189,'10','15','5',18,20,NULL,7000),(190,'16','22.5','8',4,20,NULL,7000),(191,'13.5','20','5',6,21,NULL,5400),(192,'16','14','0',12,21,NULL,7000),(193,'9','16','0',20,21,NULL,7000),(194,'7','14','0',28,21,NULL,7000),(195,'9','12','0',18,21,NULL,5400),(196,'15','11.5','0',16,21,NULL,7000),(197,'7','7','0',48,21,NULL,5400),(198,'6','10','0',42,21,NULL,7000),(199,'5.5','5.5','0',90,21,NULL,7000),(200,'10.5','15','0',15,21,NULL,5400),(201,'12.5','10','0',20,21,NULL,7000),(202,'12','13','0',16,21,NULL,7000),(203,'7','6','0',60,21,NULL,5400),(204,'6.1','7','0',60,21,NULL,7000),(205,'9','9','0',27,21,NULL,5400),(206,'10.1','15.1','0',18,21,NULL,7000),(207,'15','17','0',12,21,NULL,7000),(208,'31','16','4.5',2,22,NULL,5400),(209,'10','20','3.5',12,22,NULL,7000),(210,'9','28','6',6,23,NULL,5400),(211,'9','32','8',6,23,NULL,7000),(212,'10','28','5',6,23,NULL,7000),(213,'12','24','6.5',4,23,NULL,5400),(214,'10','32','5.5',6,23,NULL,7000),(215,'9','9','5',12,23,NULL,7000),(216,'9.7','27','7.5',4,23,NULL,7000),(217,'9.7','24','7.5',8,23,NULL,7000),(218,'21.8','34','10.9',2,23,NULL,7000),(219,'10','13','5',12,23,NULL,5400),(220,'8.5','17','1.7',12,23,NULL,7000),(221,'8.5','22.4','3',8,23,NULL,7000),(222,'9.5','19','2',8,23,NULL,7000),(223,'6.7','18','2',18,23,NULL,7000),(224,'8.4','18,5','5.5',8,23,NULL,5400),(225,'6','14','1.2',24,23,NULL,7000),(226,'9','19','6.5',9,23,NULL,7000),(227,'14.5','27','8.5',4,23,NULL,7000),(228,'9','26','6.5',6,23,NULL,7000),(229,'14.5','24','4',4,23,NULL,7000),(230,'7.5','12.9','5.2',12,23,NULL,7000),(231,'28','12','7',4,23,NULL,5400),(232,'6','16','2.5',16,23,NULL,7000),(233,'8.5','17','3',12,23,NULL,7000),(234,'8.5','28','3',8,23,NULL,7000),(235,'11.5','23.5','6.5',5,23,NULL,7000),(236,'16','26','4',6,23,NULL,7000),(237,'19.5','33.5','4.5',2,23,NULL,7000),(238,'14','9','6.5',12,23,NULL,7000),(239,'10','24.5','5',6,24,NULL,7000),(240,'8.5','14','1.3',16,24,NULL,7000),(241,'9.5','18','2',8,24,NULL,5400),(242,'12','9','38',0,7,NULL,NULL),(243,'15','8.5','38',0,7,NULL,NULL),(244,'19','9.5','42',0,7,NULL,NULL),(245,'22','11.5','46',0,7,NULL,NULL),(246,'22','11.5','50',0,7,NULL,NULL),(247,'22','11.5','55',0,7,NULL,NULL),(248,'22','11.5','60',0,7,NULL,NULL),(249,'25','13.5','46',0,7,NULL,NULL),(250,'25','13.5','50',0,7,NULL,NULL),(251,'25','13.5','55',0,7,NULL,NULL),(252,'25','13.5','60',0,7,NULL,NULL),(253,'25','13.5','73',0,7,NULL,NULL),(254,'30','13.5','50',0,7,NULL,NULL),(255,'30','13.5','55',0,7,NULL,NULL),(256,'30','13.5','60',0,7,NULL,NULL),(257,'30','13.5','73',0,7,NULL,NULL),(258,'30','16','60',0,7,NULL,NULL),(259,'30','16','73',0,7,NULL,NULL),(260,'30','16','80',0,7,NULL,NULL),(261,'30','16','92',0,7,NULL,NULL),(262,'39','12','60',0,7,NULL,NULL),(263,'39','12','73',0,7,NULL,NULL),(264,'39','12','80',0,7,NULL,NULL),(265,'39','12','92',0,7,NULL,NULL),(266,'39','19','73',0,7,NULL,NULL),(267,'39','19','80',0,7,NULL,NULL),(268,'39','19','92',0,7,NULL,NULL),(269,'10.5','4.5','14',6,25,NULL,NULL),(270,'10','2','9',16,26,NULL,NULL),(271,'14','5','10.5',6,27,NULL,NULL),(272,'11.5','2.5','11.5',12,28,NULL,NULL),(273,'27.5','2.5','10.5',8,29,NULL,NULL),(274,'19.1','3.2','11.2',8,30,NULL,NULL),(275,'14','5','10',12,30,NULL,NULL),(276,'19','3.5','9',16,30,NULL,NULL),(277,'16','3.9','10',12,30,NULL,NULL),(278,'11','3.7','7.5',16,30,NULL,NULL),(279,'9','7','4.5',12,30,NULL,NULL),(280,'20','12.5','5',8,30,NULL,NULL),(281,'9.5','20','2.5',12,30,NULL,NULL),(282,'10.5','14','5',9,30,NULL,NULL),(283,'9.3','18.3','5',9,30,NULL,NULL),(284,'9.1','12','3.9',16,30,NULL,NULL),(285,'7.5','10','2.5',10,30,NULL,NULL),(286,'13','0','10.5',16,30,NULL,NULL),(287,'10','10','3.5',18,30,NULL,NULL),(288,'7.5','2.5','10.5',20,30,NULL,NULL),(289,'7','4','9',16,31,NULL,NULL),(290,'8.6','10.2','6',12,31,NULL,NULL),(291,'8','10','6',12,31,NULL,NULL),(292,'13','14','11.5',24,31,NULL,NULL),(293,'19','19','1',18,31,NULL,NULL),(294,'22.5','22.5','1.3',10,31,NULL,NULL),(295,'25','4','5',12,32,NULL,NULL),(296,'4.2','15','5.5',16,32,NULL,NULL),(297,'4','21','4',14,32,NULL,NULL),(298,'9','25','5',6,32,NULL,NULL),(299,'5.5','17.5','4.2',16,32,NULL,NULL),(300,'5.5','17.5','4',16,32,NULL,NULL),(301,'5','25','4',12,32,NULL,NULL),(302,'7','26','5',12,32,NULL,NULL),(303,'7','4','9',12,33,NULL,NULL),(304,'17.5','4','5',12,34,NULL,NULL),(305,'22','5','6',12,34,NULL,NULL),(306,'15.5','9','10',12,35,NULL,NULL),(307,'8.5','8','7.5',16,35,NULL,NULL),(308,'9','10','3',16,35,NULL,NULL),(309,'21','4','5.5',12,36,NULL,NULL),(310,'17.5','4','5.5',16,36,NULL,NULL),(311,'5','25','4',14,36,NULL,NULL),(312,'5.5','20','4',12,36,NULL,NULL),(313,'15','3.2','7.4',12,37,NULL,NULL),(314,'11','3.5','7.3',16,38,NULL,NULL),(315,'9','11','3',16,39,NULL,NULL),(316,'11.8','12.8','1.8',24,39,NULL,NULL),(317,'21.3','1.5','8',6,39,NULL,NULL),(318,'20.5','4.7','4.5',12,39,NULL,NULL),(319,'6','6','2',54,40,NULL,NULL),(320,'7.5','7.5','3',24,40,NULL,NULL),(321,'25.9','13','4',4,41,NULL,NULL),(322,'9.3','18','3.5',6,41,NULL,NULL),(323,'7.2','10','4',16,42,NULL,NULL),(324,'12','12','4',12,43,NULL,NULL),(325,'13','13','2',6,44,NULL,NULL),(326,'6.6','6.6','5.4',12,45,NULL,NULL),(327,'13','9','4',12,45,NULL,NULL),(328,'7.5','11','4',16,45,NULL,NULL),(329,'5','25','4',15,46,NULL,NULL),(330,'10.5','21','5',15,46,NULL,NULL),(331,'8','10','3',10,47,NULL,NULL),(332,'10','9.5','3',16,47,NULL,NULL),(333,'23','13.5','6.5',6,47,NULL,NULL),(334,'7.5','11','4.5',18,48,NULL,NULL),(335,'7.5','18','4.2',10,49,NULL,NULL),(336,'9.5','16','1.5',12,50,NULL,NULL),(337,'10.5','14.5','5',12,51,NULL,NULL),(338,'9','14.2','6',4,52,NULL,NULL),(339,'6','5.9','6.3',27,53,NULL,NULL),(340,'4','13.4','3.8',32,54,NULL,NULL),(341,'8','10','3.3',24,55,NULL,NULL),(342,'17','19','1.2',16,56,NULL,NULL),(343,'19','18.5','1.5',18,56,NULL,NULL),(344,'16','18','1',10,56,NULL,NULL),(345,'2.6','14','2.8',30,57,NULL,NULL),(346,'28','28','4',2,58,NULL,NULL),(347,'4.7','7.2','5',12,59,NULL,NULL),(348,'9','19','3',12,60,NULL,NULL),(349,'7.5','18','4',16,61,NULL,NULL),(350,'7.5','11','3.7',18,62,NULL,NULL),(351,'35','35','4',2,63,NULL,NULL),(352,'18.5','1','14',16,64,NULL,NULL),(353,'20.5','16','8',16,64,NULL,NULL),(354,'14.6','21','8',16,64,NULL,NULL),(355,'18','18','1',12,64,NULL,NULL),(356,'11.3','0','12',48,65,NULL,NULL),(357,'35','0','11.8',4,66,NULL,NULL),(358,'6','6','3',40,67,NULL,NULL),(359,'34','0','48',4,68,NULL,NULL),(360,'30','0','30',6,68,NULL,NULL),(361,'15','0','15',24,68,NULL,NULL),(362,'11.3','2.5','11.3',24,69,NULL,NULL),(363,'12','18.5','4',18,69,NULL,NULL),(364,'12','20','2',15,69,NULL,NULL),(365,'10.2','10.2','2',24,69,NULL,NULL),(366,'8','14','8',16,70,NULL,NULL),(367,'18','14','6',2,71,NULL,NULL),(368,'4.5','8.7','4',16,72,NULL,NULL),(369,'12.3','8','8.5',8,73,NULL,NULL),(370,'28','17','4',4,74,NULL,NULL),(1144,'7','0','12',1,8,NULL,NULL),(1145,'7','0','14',1,8,NULL,NULL),(1146,'7','0','24',1,8,NULL,NULL),(1147,'7','0','28',1,8,NULL,NULL),(1148,'8','0','12',2,8,NULL,NULL),(1149,'8','0','14',2,8,NULL,NULL),(1150,'8','0','24',2,8,NULL,NULL),(1151,'8','0','28',2,8,NULL,NULL),(1152,'9','0','12',3,8,NULL,NULL),(1153,'9','0','14',3,8,NULL,NULL),(1154,'9','0','24',3,8,NULL,NULL),(1155,'9','0','28',3,8,NULL,NULL),(1156,'10','0','12',4,8,NULL,NULL),(1157,'10','0','14',4,8,NULL,NULL),(1158,'10','0','16',4,8,NULL,NULL),(1159,'10','0','17',4,8,NULL,NULL),(1160,'10','0','19',4,8,NULL,NULL),(1161,'10','0','24',4,8,NULL,NULL),(1162,'10','0','28',4,8,NULL,NULL),(1163,'10','0','32',4,8,NULL,NULL),(1164,'11','0','12',5,8,NULL,NULL),(1165,'11','0','14',5,8,NULL,NULL),(1166,'11','0','16',5,8,NULL,NULL),(1167,'11','0','17',5,8,NULL,NULL),(1168,'11','0','19',5,8,NULL,NULL),(1169,'11','0','24',5,8,NULL,NULL),(1170,'11','0','28',5,8,NULL,NULL),(1171,'11','0','32',5,8,NULL,NULL),(1172,'12','0','12',6,8,NULL,NULL),(1173,'12','0','14',6,8,NULL,NULL),(1174,'12','0','16',6,8,NULL,NULL),(1175,'12','0','17',6,8,NULL,NULL),(1176,'12','0','19',6,8,NULL,NULL),(1177,'12','0','24',6,8,NULL,NULL),(1178,'12','0','28',6,8,NULL,NULL),(1179,'12','0','32',6,8,NULL,NULL),(1180,'13','0','19',7,8,NULL,NULL),(1181,'15','0','20',8,8,NULL,NULL),(1182,'15','0','24',8,8,NULL,NULL),(1183,'15','0','28',8,8,NULL,NULL),(1184,'15','0','32',8,8,NULL,NULL),(1185,'15','0','34',8,8,NULL,NULL),(1186,'15','0','38',8,8,NULL,NULL),(1187,'15','0','50',8,8,NULL,NULL),(1188,'15','0','62',8,8,NULL,NULL),(1189,'17','0','20',7,8,NULL,NULL),(1190,'17','0','24',7,8,NULL,NULL),(1191,'17','0','28',7,8,NULL,NULL),(1192,'17','0','32',7,8,NULL,NULL),(1193,'17','0','34',7,8,NULL,NULL),(1194,'17','0','38',7,8,NULL,NULL),(1195,'17','0','50',7,8,NULL,NULL),(1196,'17','0','62',7,8,NULL,NULL),(1197,'19','0','24',9,8,NULL,NULL),(1198,'19','0','28',9,8,NULL,NULL),(1199,'19','0','32',9,8,NULL,NULL),(1200,'19','0','34',9,8,NULL,NULL),(1201,'19','0','38',9,8,NULL,NULL),(1202,'19','0','50',9,8,NULL,NULL),(1203,'19','0','62',9,8,NULL,NULL),(1204,'21','0','24',11,8,NULL,NULL),(1205,'21','0','28',11,8,NULL,NULL),(1206,'21','0','32',11,8,NULL,NULL),(1207,'21','0','34',11,8,NULL,NULL),(1208,'21','0','38',11,8,NULL,NULL),(1209,'21','0','50',11,8,NULL,NULL),(1210,'21','0','62',11,8,NULL,NULL),(1211,'26','0','28',14,8,NULL,NULL),(1212,'26','0','32',14,8,NULL,NULL),(1213,'26','0','34',14,8,NULL,NULL),(1214,'26','0','38',14,8,NULL,NULL),(1215,'26','0','50',14,8,NULL,NULL),(1216,'26','0','62',14,8,NULL,NULL),(1217,'30','0','32',18,8,NULL,NULL),(1218,'30','0','34',18,8,NULL,NULL),(1219,'30','0','38',18,8,NULL,NULL),(1220,'30','0','50',18,8,NULL,NULL),(1221,'30','0','62',18,8,NULL,NULL),(1222,'33','0','38',21,8,NULL,NULL),(1223,'33','0','50',21,8,NULL,NULL),(1224,'33','0','62',21,8,NULL,NULL),(1306,'7','4','17',1,2,NULL,NULL),(1307,'7','4','20',1,2,NULL,NULL),(1308,'7','4','24',1,2,NULL,NULL),(1309,'8','5','17',2,2,NULL,NULL),(1310,'8','5','20',2,2,NULL,NULL),(1311,'8','5','24',2,2,NULL,NULL),(1312,'8','5','28',2,2,NULL,NULL),(1313,'9','5','20',3,2,NULL,NULL),(1314,'9','5','24',3,2,NULL,NULL),(1315,'9','5','28',3,2,NULL,NULL),(1316,'9','5','34',3,2,NULL,NULL),(1317,'9','5','38',3,2,NULL,NULL),(1318,'9','5','50',3,2,NULL,NULL),(1319,'9','5','62',3,2,NULL,NULL),(1320,'9','5','70',3,2,NULL,NULL),(1321,'10','5','20',4,2,NULL,NULL),(1322,'10','5','24',4,2,NULL,NULL),(1323,'10','5','28',4,2,NULL,NULL),(1324,'11','5','20',5,2,NULL,NULL),(1325,'11','5','24',5,2,NULL,NULL),(1326,'11','5','28',5,2,NULL,NULL),(1327,'11','5','30',5,2,NULL,NULL),(1328,'11','5','34',5,2,NULL,NULL),(1329,'11','5','38',5,2,NULL,NULL),(1330,'11','5','50',5,2,NULL,NULL),(1331,'11','5','62',5,2,NULL,NULL),(1332,'11','5','70',5,2,NULL,NULL),(1333,'12','7','30',6,2,NULL,NULL),(1334,'12','7','32',6,2,NULL,NULL),(1335,'12','7','34',6,2,NULL,NULL),(1336,'12','7','38',6,2,NULL,NULL),(1337,'12','7','50',6,2,NULL,NULL),(1338,'12','7','62',6,2,NULL,NULL),(1339,'12','7','70',6,2,NULL,NULL),(1340,'15','9','38',7,2,NULL,NULL),(1341,'15','9','50',7,2,NULL,NULL),(1342,'15','9','62',7,2,NULL,NULL),(1343,'15','9','70',7,2,NULL,NULL),(1344,'17','9','38',9,2,NULL,NULL),(1345,'17','9','50',9,2,NULL,NULL),(1346,'17','9','62',9,2,NULL,NULL),(1347,'17','9','70',9,2,NULL,NULL),(1348,'19','10','38',11,2,NULL,NULL),(1349,'19','10','50',11,2,NULL,NULL),(1350,'19','10','62',11,2,NULL,NULL),(1351,'19','10','70',11,2,NULL,NULL),(1352,'21','10','38',11,2,NULL,NULL),(1353,'21','10','50',11,2,NULL,NULL),(1354,'21','10','62',11,2,NULL,NULL),(1355,'21','10','70',11,2,NULL,NULL),(1356,'26','8','38',16,2,NULL,NULL),(1357,'26','8','50',16,2,NULL,NULL),(1358,'26','8','62',16,2,NULL,NULL),(1359,'26','8','70',16,2,NULL,NULL),(1360,'26','10','38',16,2,NULL,NULL),(1361,'26','10','50',16,2,NULL,NULL),(1362,'26','10','62',16,2,NULL,NULL),(1363,'26','10','70',16,2,NULL,NULL),(1364,'30','9','38',18,2,NULL,NULL),(1365,'30','9','50',18,2,NULL,NULL),(1366,'30','9','62',18,2,NULL,NULL),(1367,'30','9','70',18,2,NULL,NULL),(1368,'30','11','38',18,2,NULL,NULL),(1369,'30','11','50',18,2,NULL,NULL),(1370,'30','11','62',18,2,NULL,NULL),(1371,'30','11','70',18,2,NULL,NULL),(1372,'33','11','38',21,2,NULL,NULL),(1373,'33','11','50',21,2,NULL,NULL),(1374,'33','11','62',21,2,NULL,NULL),(1375,'33','11','70',21,2,NULL,NULL),(1386,'15','9','38',0,5,13,NULL),(1387,'19','10','38',0,5,13,NULL),(1388,'19','12','38',0,5,13,NULL),(1389,'21','13','38',0,5,13,NULL),(1390,'21','15','38',0,5,13,NULL),(1391,'22','12','38',0,5,13,NULL),(1392,'22','15','46',0,5,13,NULL),(1401,'17','20','0',0,10,NULL,NULL),(1402,'25','35','0',0,10,NULL,NULL),(1403,'40','30','0',0,10,NULL,NULL),(1404,'45','33','0',0,10,NULL,NULL),(1411,'12','9','38',0,5,14,NULL);
/*!40000 ALTER TABLE `measurements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notices` (
  `id_notice` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `photo` varchar(500) NOT NULL,
  `hits` bigint(20) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_notice`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notices`
--

LOCK TABLES `notices` WRITE;
/*!40000 ALTER TABLE `notices` DISABLE KEYS */;
INSERT INTO `notices` (`id_notice`, `title`, `content`, `photo`, `hits`, `active`, `created_at`, `updated_at`) VALUES (1,'TE INVITAMOS A CONOCER SOBRE EL MATERIAL BIODEGRADABLE PLA QUE USAMOS EN NUESTROS EMPAQUES','<p>El PLA o &aacute;cido polil&aacute;ctico es un biopol&iacute;mero hecho con recursos renovables y tiene un gran campo de aplicaciones como es el de los film para empaques y envases flexibles. Su producci&oacute;n es f&aacute;cil, se da a partir de diferentes recursos naturales como el ma&iacute;z, la ca&ntilde;a de az&uacute;car o el almid&oacute;n y no requiere de solventes adicionales.</p><p>La energ&iacute;a necesaria para realizar la producci&oacute;n es poca, y no hay un fin del ciclo de vida de la materia ya que no se generan residuos s&oacute;lidos, pues el material que sobra de este proceso puede ser reciclado, volviendo al inicio del ciclo de fabricaci&oacute;n como materia prima; adem&aacute;s las emisiones generadas al final del proceso son m&iacute;nimas.</p><p>La utilizaci&oacute;n de pol&iacute;meros biodegradables como el ma&iacute;z, reduce notablemente la huella ambiental desde el proceso de obtenci&oacute;n de la materia prima, su producci&oacute;n, uso y reciclaje, compar&aacute;ndolo con la producci&oacute;n de los pol&iacute;meros a base de petr&oacute;leo, que no son biodegradables, adem&aacute;s el PLA compite en sus propiedades mec&aacute;nicas con los pl&aacute;sticos tradicionales.</p><p><img src=\"https://en.teenus.com.co/upload/img/IMG-1583082561-5e5bec41dcd42.png\" style=\"width: 300px;\" class=\"fr-fic fr-dib\"></p><p><br></p><p>El PLA es un material transparente, resistente e ins&iacute;pido, alternativa natural al polietileno, 100 % biodegradable y org&aacute;nico.&nbsp;</p><p><br></p><p><strong>Ciclo de vida del PLA1.</strong></p><p><img src=\"https://en.teenus.com.co/upload/img/IMG-1583082584-5e5bec58d5bc9.png\" style=\"width: 300px;\" class=\"fr-fic fr-dib\"></p><p><br></p><ol><li>Las plantas de ma&iacute;z se cosechan.</li><li>Luego se extrae el almid&oacute;n de las plantas.</li><li>Se realiza la fermentaci&oacute;n en dextrosa, y posteriormente la catalizaci&oacute;n con el biopol&iacute;mero (PLA).</li><li>Se produce el film de PLA que puede ser aplicado en diferentes productos.</li><li>Cuando los productos son desechados, estos pueden ser recolectados para convertirse en abono industrialmente.</li><li>El compost se utiliza para cultivar m&aacute;s plantas</li></ol><p>&nbsp;</p><p><strong>Beneficios del PLA en empaques</strong></p><ul><li>Est&aacute; hecho de materiales renovables</li><li>Puede estar en contacto con alimentos</li><li>Puede ser reciclado</li><li>Puede ser compostable industrialmente en f&aacute;ciles condiciones</li></ul><p>&nbsp;<img src=\"https://en.teenus.com.co/upload/img/IMG-1583082656-5e5beca066ef8.png\" style=\"width: 300px;\" class=\"fr-fic fr-dib\"></p><p>Tiene mejores propiedades mec&aacute;nicas que las l&aacute;minas de pl&aacute;sticos tradicionales:</p><ul><li>Mejores propiedades para impresi&oacute;n</li><li>Mayor rigidez</li><li>Permite un excelente plegado</li></ul><p><span class=\"fr-img-caption fr-fic fr-dib fr-draggable\" contenteditable=\"false\" draggable=\"false\" style=\"width: 400px;\"><span class=\"fr-img-wrap\"><span class=\"fr-inner\" contenteditable=\"true\"></span></span></span></p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>','https://cdn.pixabay.com/photo/2019/06/01/03/45/alpine-lake-4243396_960_720.jpg',47,1,'2019-06-07 23:47:14','2020-03-01 17:14:26'),(2,'¿QUÉ CREES QUE ES MEJOR, BIODEGRADABLE, DEGRADABLE O COMPOSTABLE (convertibles en Abono)?','<div class=\"img\"><img class=\"attachment-full size-full wp-post-image fr-fic fr-dii\" src=\"https://greenpack.com.co/wp-content/uploads/2017/07/b2.png\" sizes=\"(max-width: 580px) 100vw, 580px\" srcset=\"https://greenpack.com.co/wp-content/uploads/2017/07/b2.png 580w, https://greenpack.com.co/wp-content/uploads/2017/07/b2-300x166.png 300w\" alt=\"\" width=\"580\" height=\"320\"></div><div class=\"txt-content\"><p style=\"text-align: justify;\">Un producto es <strong>biodegradable&nbsp;</strong>si despu&eacute;s de usarlo, se descompone naturalmente por organismos vivientes o microorganismos sin necesidad de agregar productos qu&iacute;micos. El tiempo de biodegradaci&oacute;n depende de la cantidad de ox&iacute;geno, el grado de humedad y de la temperatura. Los productos biodegradables son de origen vegetal. Estos productos se biodegradan completamente en algunos meses en la tierra.</p><p style=\"text-align: justify;\"><br></p><p style=\"text-align: justify;\">Los productos<strong>&nbsp;degradables&nbsp;</strong>(o oxobiodegradable o fragmentable) de origen petrol&iacute;fero, est&aacute;n constituidos de polietileno PE y de aditivos qu&iacute;micos. En presencia de ox&iacute;geno, bajo el efecto del calor y de los UV, pierden resistencia mec&aacute;nica, se fragmentan y desaparecen visualmente.</p><p style=\"text-align: justify;\"><br></p><p style=\"text-align: justify;\">Los t&eacute;rminos biodegradable y <strong>compostable&nbsp;</strong>no tienen el mismo significado. Un producto biodegradable puede ser descompuesto por microorganismos, pero esto no significa que se obtendr&aacute; un abono de buena calidad, es decir compostable. Un producto biodegradable no es necesariamente compostable, pero un producto compostable es obligatoriamente biodegradable.</p><p style=\"text-align: justify;\"><br></p><p style=\"text-align: justify;\">El <strong>compostaje&nbsp;</strong>es un proceso biol&oacute;gico natural que permite la conversi&oacute;n y la valorizaci&oacute;n de materias org&aacute;nicas en un producto rico en compuestos h&uacute;micos, en presencia de ox&iacute;geno. Al final del proceso org&aacute;nico, obtenemos el abono, mantillo o humus directamente utilizable en agricultura. El abono evita las incineraciones costosas y contaminantes y valoriza el reciclaje de nuestros desechos.</p><p style=\"text-align: justify;\">La diferencia entre un compostaje dom&eacute;stico y un compostaje industrial es esencialmente la temperatura y el tiempo. En un compostaje hecho industrialmente, la temperatura es de 75&deg;, 80&deg;C, la humedad de 65, 70% y el ox&iacute;geno de 1 8 a 20 %. En estas condiciones, el tiempo de compostaje es de aproximadamente 12 semanas. En un compostaje de jard&iacute;n, la temperatura no pasa de 40&deg;C y la humedad depende de la estaci&oacute;n y de la latitud. El tiempo de compostaje es mucho m&aacute;s largo, puede tomar varios meses.</p></div><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>','https://cdn.pixabay.com/photo/2019/06/05/06/42/flower-4253120_960_720.jpg',24,1,'2019-06-08 00:29:15','2020-03-01 17:23:04'),(4,'LA HORA Y EL AHORA DE NUESTRA PLANETA','<div class=\"txt-content\"><p>Una urgente acci&oacute;n por parte de los colombianos es necesaria para detener la desenfrenada deforestaci&oacute;n que tiene lugar en Colombia. Las &uacute;ltimas cifras nacionales publicadas por el IDEAM indican que, en&nbsp;<strong>2016, se deforestaron 178.597 hect&aacute;reas de bosque en nuestro pa&iacute;s</strong>. Es demasiado: significa que cada d&iacute;a se talan 489 hect&aacute;reas &ndash;20 de ellas cada hora&ndash; y que, a diario, desaparece el equivalente en extensi&oacute;n de bosques a<strong>&nbsp;690 canchas de futbol.</strong> Este ritmo de tala arriesga ecosistemas que son vitales para nuestra supervivencia, pues los bosques nos proveen, por nombrar un primer ejemplo, del agua que bebemos. Tambi&eacute;n nos dan el agua con la que operan las hidroel&eacute;ctricas, y nos proveen de alimentos, de insumos para medicinas naturales y de madera en todo su amplio uso. Adem&aacute;s, capturan y guardan gran parte de los Gases de Efecto Invernadero que emitimos a trav&eacute;s de nuestras actividades como sociedad, causantes del cambio clim&aacute;tico.</p><p>&nbsp;</p><p>Es por eso que <strong>La Hora del Planeta</strong>, una campa&ntilde;a global de WWF,&nbsp;<strong>se suma en Colombia a Bosques Territorios de Vida</strong>, la Estrategia Integral de Control a la Deforestaci&oacute;n y Gesti&oacute;n de los Bosques, que es liderada por el&nbsp;<strong>Ministerio de Ambiente y Desarrollo Sostenible</strong>, que cuenta con el apoyo del programa&nbsp;<strong>ONU-REDD</strong> y que implementan el&nbsp;<strong>PNUD</strong>,&nbsp;<strong>FAO</strong> y&nbsp;<strong>ONU Medio Ambiente</strong> con el Fondo Cooperativo del Carbono de los Bosques, el&nbsp;<strong>Banco Mundial</strong> y el&nbsp;<strong>Fondo Acci&oacute;n</strong>. El prop&oacute;sito fundamental de la estrategia es fortalecer un desarrollo sostenible que incluya a los bosques como eje de la econom&iacute;a, garantizando el cumplimiento de la meta de deforestaci&oacute;n neta cero en todo el pa&iacute;s para el a&ntilde;o 2030.<br><br>La Hora del Planeta<a href=\"http://www.conectadosporlosbosques.com/\" rel=\"noopener\" target=\"_blank\"><strong>&nbsp;invita este a&ntilde;o a toda la sociedad colombiana a movilizarse para proteger y valorar sus bosques</strong></a>, ya que constituyen tesoros naturales no s&oacute;lo para nuestro pa&iacute;s, sino para el mundo. &iquest;En qu&eacute; consiste esta movilizaci&oacute;n? Se realizar&aacute; a trav&eacute;s de tres grandes llamados a la acci&oacute;n:<br>&nbsp;</p><ol><li>El primero es a hacer parte del gran movimiento nacional por los bosques. Todos los colombianos nos podemos unir en la p&aacute;gina <a href=\"http://www.conectadosporlosbosques.com/\" rel=\"noopener\" target=\"_blank\"><strong>www.conectadosporlosbosques.com</strong></a></li><li>El segundo es a que utilicemos el hashtag <strong>#ConectadosPorLosBosques</strong> en nuestras redes sociales cuando expresemos nuestra preocupaci&oacute;n por estos ecosistemas y nuestro compromiso con su conservaci&oacute;n.</li><li>El tercero es participar en los eventos a realizarse el s&aacute;bado 24 de marzo durante La Hora del Planeta en m&aacute;s de 20 ciudades del pa&iacute;s. La informaci&oacute;n relacionada con estos actos se estar&aacute; actualizando en la p&aacute;gina <a href=\"http://www.lahoradelplanetacolombia.com/\" rel=\"noopener\" target=\"_blank\"><strong>www.lahoradelplanetacolombia.com</strong></a></li></ol></div><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>','https://cdn.pixabay.com/photo/2018/02/22/10/42/summer-3172634_960_720.jpg',37,1,'2019-06-08 00:54:59','2020-03-01 17:18:16'),(5,'¿CÓMO CUIDAR NUESTROS BOSQUES COLOMBIANOS?','<p style=\"text-align: justify;\">Proteger los bosques es necesario para nuestra vida, pues contribuye a conservar m&uacute;ltiples recursos naturales como la producci&oacute;n de agua, la regulaci&oacute;n del clima, la captura de carbono para enfrentar el cambio clim&aacute;tico, la polinizaci&oacute;n y la dispersi&oacute;n de semillas. Pero no solo eso. Adem&aacute;s, contribuye a preservar las relaciones sociales y la cultura que se genera alrededor de estos ecosistemas. En Colombia, casi la mitad de los bosques naturales est&aacute;n en territorios ind&iacute;genas, campesinos y afrodescendientes.&nbsp;</p><p style=\"text-align: justify;\">Nuestro pa&iacute;s es el segundo con mayor diversidad de &aacute;rboles y sus bosques, que cubren 53% del territorio nacional, son un tesoro natural. Sin embargo, est&aacute;n en peligro. El 75% de la madera que se extrae y comercia en el pa&iacute;s proviene de la ilegalidad. Esta es una de las razones por las cuales, en 2017, creci&oacute; la deforestaci&oacute;n un 23% con respecto al a&ntilde;o anterior en todo el pa&iacute;s. En ese periodo se talaron en promedio, 25 hect&aacute;reas de bosque natural cada hora. Las regiones Amaz&oacute;nica y Andina son las principales afectadas.</p><p><strong>Cuando un producto tiene el sello FSC</strong></p><p><img data-fr-image-pasted=\"true\" src=\"https://greenpack.com.co/wp-content/uploads/2018/08/untitled-300x225.png\" alt=\"\" width=\"300\" height=\"225\" class=\"fr-fic fr-dii\"></p><ol><li>Proviene de fuentes legales.&nbsp;</li><li>Respeta las leyes colombianas y los acuerdos internacionales sobre recursos forestales y derechos de los trabajadores.&nbsp;</li><li>Proviene de producciones sostenibles, donde la extracci&oacute;n no afecta los procesos naturales del bosque.&nbsp;</li><li>Cuida las fuentes de agua.&nbsp;</li><li>Protege los valores de conservaci&oacute;n (naturales o culturales) dentro de las operaciones forestales.&nbsp;</li><li>Las plagas son reguladas de manera cuidadosa con el medio ambiente.&nbsp;</li><li>Respeta y promueve los derechos de los pueblos ind&iacute;genas.&nbsp;</li><li>Es social y econ&oacute;micamente beneficioso para los pueblos aleda&ntilde;os.</li><li>Minimiza los desperdicios y los aprovecha en otros productos.&nbsp;</li><li>Respeta las &aacute;reas de preservaci&oacute;n establecidas por el gobierno. &nbsp;</li><li>Prev&eacute; protecci&oacute;n para especies en peligro de extinci&oacute;n.</li></ol><p style=\"text-align: justify;\">&nbsp;Gracias por cuidar nuestros bosques</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>','https://cdn.pixabay.com/photo/2015/09/09/16/05/forest-931706_960_720.jpg',40,1,'2019-06-08 00:58:09','2020-03-01 17:16:01'),(6,'¿ES REALMENTE BUENO RECICLAR?','<p>La fabricaci&oacute;n de papel reciclado ayuda a la preservaci&oacute;n del medio ambiente, ya que sustituye la celulosa virgen, al mismo tiempo que reducen el costo de fabricaci&oacute;n de los productos manteniendo los est&aacute;ndares de calidad.</p><p>&nbsp;</p><p><strong>Ciclo del papel reciclado</strong></p><p><strong><img data-fr-image-pasted=\"true\" src=\"http://greenpack.com.co/images/rec3.png\" alt=\"\" border=\"0\" class=\"fr-fic fr-dib\"></strong></p><p><img src=\"https://en.teenus.com.co/upload/img/IMG-1583083616-5e5bf06056ad0.png\" style=\"width: 300px;\" class=\"fr-fic fr-dib\"></p><p style=\"text-align: justify;\">El proceso de fabricaci&oacute;n comienza con la recolecci&oacute;n de papeles y cartones que han terminado su uso. (Papel blanco, de colores, con impresi&oacute;n, revistas, cart&oacute;n, peri&oacute;dicos, libros, folletos, carpetas, sobres, correspondencia, bolsas de papel, etc.)</p><p style=\"text-align: justify;\"><br></p><p style=\"text-align: justify;\">Estos son llevados a la planta donde pasan principalmente por un proceso de clasificaci&oacute;n para retirar cualquier material diferente como ganchos, pl&aacute;sticos, u otros y luego se lavan con agua y qu&iacute;micos en altas temperaturas para retirar tintas.</p><p style=\"text-align: justify;\"><br></p><p style=\"text-align: justify;\">Los papeles son triturados en los Pulpers (licuadoras enormes), para obtener pulpa nuevamente y fabricar papel con el mismo proceso de la fabricaci&oacute;n del papel a partir de fibra virgen. El papel reciclado puede ser usado nuevamente hasta 10 veces para la fabricaci&oacute;n de productos de segundo uso como cajas de cart&oacute;n, bolsas de papel, papel para escritura e impresi&oacute;n, papel higi&eacute;nico, papel peri&oacute;dico, empaque, moldeado, entre otros; NO es apto para contacto con alimentos. Con este proceso se cierra el ciclo de fabricaci&oacute;n del papel y siendo un proceso sostenible, con un impacto ambiental positivo.</p><p style=\"text-align: justify;\"><br></p><p style=\"text-align: justify;\">&iquest;Qu&eacute; piensas ahora?</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>','https://en.teenus.com.co/upload/img/IMG-1583083825-5e5bf1319eba5.jpg',0,1,'2020-03-01 17:30:29','2020-03-01 17:31:13');
/*!40000 ALTER TABLE `notices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `numbers_home`
--

DROP TABLE IF EXISTS `numbers_home`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `numbers_home` (
  `id_numbers` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8_spanish_ci NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id_numbers`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `numbers_home`
--

LOCK TABLES `numbers_home` WRITE;
/*!40000 ALTER TABLE `numbers_home` DISABLE KEYS */;
INSERT INTO `numbers_home` (`id_numbers`, `name`, `value`) VALUES (1,'productos',2500),(2,'innovaciones',220),(3,'clientes',450);
/*!40000 ALTER TABLE `numbers_home` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_image`
--

DROP TABLE IF EXISTS `product_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_image` (
  `id_product_image` int(11) NOT NULL AUTO_INCREMENT,
  `file_image` varchar(500) NOT NULL,
  `products_id_products` int(11) NOT NULL,
  PRIMARY KEY (`id_product_image`,`products_id_products`),
  KEY `fk_product_image_products_idx` (`products_id_products`),
  CONSTRAINT `fk_product_image_products` FOREIGN KEY (`products_id_products`) REFERENCES `products` (`id_products`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_image`
--

LOCK TABLES `product_image` WRITE;
/*!40000 ALTER TABLE `product_image` DISABLE KEYS */;
INSERT INTO `product_image` (`id_product_image`, `file_image`, `products_id_products`) VALUES (1,'https://greenpack.com.co/wp-content/uploads/2017/07/b-saco-in.png',7),(2,'https://greenpack.com.co/wp-content/uploads/2017/07/b-laminada.png',3),(2,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',25),(3,'https://en.teenus.com.co/upload/img/IMG-1565387962-5d4decba0d78f.png',3),(4,'https://en.teenus.com.co/upload/img/IMG-1565899156-5d55b99499f1c.jpg',2),(5,'https://en.teenus.com.co/upload/img/IMG-1565900124-5d55bd5c202ac.jpg',2),(6,'https://en.teenus.com.co/upload/img/IMG-1565900345-5d55be39a35ef.jpg',2),(7,'https://en.teenus.com.co/upload/img/IMG-1565903307-5d55c9cb879d0.jpg',5),(8,'https://en.teenus.com.co/upload/img/IMG-1565903315-5d55c9d3798cd.jpg',5),(9,'https://en.teenus.com.co/upload/img/IMG-1565903315-5d55c9d393da9.jpg',5),(10,'https://en.teenus.com.co/upload/img/IMG-1565906139-5d55d4db8065b.jpg',8),(11,'https://en.teenus.com.co/upload/img/IMG-1565906139-5d55d4db804bb.jpg',8),(12,'https://en.teenus.com.co/upload/img/IMG-1565906140-5d55d4dc638cc.jpg',8),(156,'https://en.teenus.com.co/upload/img/IMG-1575310691-5de5556377381.jpg',10),(157,'https://en.teenus.com.co/upload/img/IMG-1575382845-5de66f3d4978d.jpg',11),(158,'https://en.teenus.com.co/upload/img/IMG-1575383030-5de66ff6693ab.jpg',12),(160,'https://en.teenus.com.co/upload/img/IMG-1575383510-5de671d65f9d2.png',13),(161,'https://en.teenus.com.co/upload/img/IMG-1575385318-5de678e654e9c.jpg',14),(162,'https://en.teenus.com.co/upload/img/IMG-1575385342-5de678feb0b70.jpg',15),(163,'https://en.teenus.com.co/upload/img/IMG-1575385364-5de679142e163.jpg',16),(164,'https://en.teenus.com.co/upload/img/IMG-1575385383-5de67927da7df.jpg',17),(165,'https://en.teenus.com.co/upload/img/IMG-1575385429-5de6795544124.jpg',18),(166,'https://en.teenus.com.co/upload/img/IMG-1575385455-5de6796f947d5.jpg',19),(167,'https://en.teenus.com.co/upload/img/IMG-1575385475-5de67983727c2.jpg',20),(168,'https://en.teenus.com.co/upload/img/IMG-1575385488-5de67990e48ef.jpg',21),(169,'https://en.teenus.com.co/upload/img/IMG-1575385506-5de679a27b1d9.jpg',22),(170,'https://en.teenus.com.co/upload/img/IMG-1575385532-5de679bca27a8.jpg',23),(171,'https://en.teenus.com.co/upload/img/IMG-1575385554-5de679d2ec7ea.jpg',24),(173,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',26),(174,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',27),(175,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',28),(176,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',29),(177,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',30),(178,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',31),(179,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',32),(180,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',33),(181,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',34),(182,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',35),(183,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',36),(184,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',37),(185,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',38),(186,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',39),(187,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',40),(188,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',41),(189,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',42),(190,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',43),(191,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',44),(192,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',45),(193,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',46),(194,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',47),(195,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',48),(196,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',49),(197,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',50),(198,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',51),(199,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',52),(200,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',53),(201,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',54),(202,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',55),(203,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',56),(204,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',57),(205,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',58),(206,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',59),(207,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',60),(208,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',61),(209,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',62),(210,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',63),(211,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',64),(212,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',65),(213,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',66),(214,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',67),(215,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',68),(216,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',69),(217,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',70),(218,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',71),(219,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',72),(220,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',73),(221,'https://cdn.pixabay.com/photo/2017/10/18/14/31/box-2864328_960_720.png',74),(222,'https://greenpack.teenus.com.co/upload/img/IMG-1581997436-5e4b5d7c8bd6b.jpg',75);
/*!40000 ALTER TABLE `product_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id_products` int(11) NOT NULL AUTO_INCREMENT,
  `ref` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `price` varchar(45) NOT NULL,
  `description` text NOT NULL,
  `categories_id_categories` int(11) NOT NULL,
  `uses` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id_products`),
  KEY `fk_products_categories1_idx` (`categories_id_categories`),
  CONSTRAINT `fk_products_categories1` FOREIGN KEY (`categories_id_categories`) REFERENCES `categories` (`id_categories`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id_products`, `ref`, `name`, `price`, `description`, `categories_id_categories`, `uses`) VALUES (2,'004','Bolsas Plegadas','2000','<p>Protegen y preservan sus productos ante los rayos solares y el medio ambiente hostil. Bolsas que poseen fuelles Laterales y fondo plano. Especiales para productos con volumen. Se adaptan perfectamente para contener y proteger especialmente a su producto.&nbsp;</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',1,'[\"Panaderías\",\"Confiterías\",\"Misceláneas\",\"Cafeterías\",\"Comidas rápidas\",\"Protección de frutos en cosecha y poscosecha\",\"Farmacias\"]'),(3,'002','Bolsas Laminadas','2000','<p>Est&aacute;n elaboradas en papeles especiales que se adaptan perfectamente para contener y proteger sus producto. El &nbsp;aroma de sus productos se conservara naturalmente.</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',1,'[\"asd\"]'),(5,'001','Bolsa Fondo Automático','1000','<p>Nuestras bolsas tipo autom&aacute;tica es com&uacute;n usarlas en domicilios para comida. Proporcionan una buena conservaci&oacute;n del estado natural del alimento, debido a que eliminan la condensaci&oacute;n de la humedad dentro del empaque. Su base cuadrada o rectangular le permite auto soportarse en forma vertical. Evita la p&eacute;rdida o maltrato del contenido en el momento del llenado. Facilita una mejor acomodaci&oacute;n de los productos en su interior.</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',1,'[\"Domicilios\",\"Supermercados\",\"Tiendas (general)\"]'),(7,'005','Sacos Industriales','1200','<p>as</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',1,'[\"medicina\"]'),(8,'003','Bolsas Planas','32344','<p style=\"text-align: justify;\">Util&iacute;cela para empacar adecuadamente sus productos, adem&aacute;s de protegerlos de las condiciones ambientales. Para largos periodos de tiempo es perfecta, ya que conserva las condiciones constantes 0en el interior del empaque para y as&iacute; no deteriorar sus productos.</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',1,'[\"Droguerias (Medicamentos como Pastillas)\",\"Fritos (papas fritas, Nuggets, porciones pequeñas)\",\"Cubiertos\",\"Servilletas\",\"Billetes\",\"Botoneria (elementos pequeños)\",\"Joyeria\"]'),(10,'lam-indi','Individuales','1000','<p>Protegen tu producto desde la preparaci&oacute;n hasta el consumo.&nbsp;</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',6,'[]'),(11,'lma-01','Laminas Antigrasa','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',6,'[]'),(12,'lm-02','Laminas Enceradas','2000','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',6,'[]'),(13,'lm-03','Separadores','2000','<p>Protegen tu producto desde la preparaci&oacute;n hasta el consumo</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',6,'[]'),(14,'4p','4p','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8,'[]'),(15,'4p-V','4p con ventanilla','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8,'[]'),(16,'5p','5p','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8,'[]'),(17,'5p-V','5p con ventanilla','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8,'[]'),(18,'BL-03','bolsa triangulo para te','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8,'[]'),(19,'BL-04','DoyPack','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8,'[]'),(20,'BL-05','DoyPack con ventanilla','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8,'[]'),(21,'BL-06','Sachet','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8,'[]'),(22,'BL-07','Sachet con Translape','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8,'[]'),(23,'BL-08','Traslape','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8,'[]'),(24,'BL-09','Traslape con Ventanilla','200','<p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8,'[]'),(25,'CS-01','Bandeja Airlines','0','h',5,'[]'),(26,'CS-02','Estuche Arepas','0','h',5,'[]'),(27,'CS-04','Bandeja Copa Airlines','0','h',5,'[]'),(28,'CS-05','Greenpack Perenshaal','0','h',5,'[]'),(29,'CS-06','Caja Flat Tray Tomatoes','0','h',5,'[]'),(30,'CS-07','Bandeja','0','h',5,'[]'),(31,'CS-08','Caja Papas','0','h',5,'[]'),(32,'CS-09','Porta Perro','0','h',5,'[]'),(33,'CS-10','Bandeja porta Papas plegable','0','h',5,'[]'),(34,'CS-11','Bandeja Perro','0','h',5,'[]'),(35,'CS-12','Caja papas Fritas','0','h',5,'[]'),(36,'CS-13','Caja Perro','0','h',5,'[]'),(37,'CS-14','Plato Grande','0','h',5,'[]'),(38,'CS-15','Caja Pequeña','0','h',5,'[]'),(39,'CS-16','Nido','0','h',5,'[]'),(40,'CS-17','Plato Pequeño','0','h',5,'[]'),(41,'CS-18','Portavasos','0','h',5,'[]'),(42,'CS-19','Caja Arepa','0','h',5,'[]'),(43,'CS-20','Bandeja papas sin Pegue','0','h',5,'[]'),(44,'CS-21','Plato Genérico ','0','h',5,'[]'),(45,'CS-22','Caja Generica','0','h',5,'[]'),(46,'CS-23','Porta pinchos','0','h',5,'[]'),(47,'CS-24','Caja Porta papas','0','h',5,'[]'),(48,'CS-25','Caja Papas generica','0','h',5,'[]'),(49,'CS-26','Bandeja Platanos','0','h',5,'[]'),(50,'CS-27','Porta Arepas','0','h',5,'[]'),(51,'CS-28','Troquel Carritp','0','h',5,'[]'),(52,'CS-29','Caja Maiz Pira','0','h',5,'[]'),(53,'CS-30','Soporte Pollo','0','h',5,'[]'),(54,'CS-31','Soporte Wrap Pollo','0','h',5,'[]'),(55,'CS-32','Caja Sin impresión','0','h',5,'[]'),(56,'CS-33','Porta Pizza','0','h',5,'[]'),(57,'CS-34','Porta Tacos','0','h',5,'[]'),(58,'CS-35','Caja Familiar','0','h',5,'[]'),(59,'CS-36','Caja Hamburguesa','0','h',5,'[]'),(60,'CS-37','Caja la popular','0','h',5,'[]'),(61,'CS-38','Caja Choripan','0','h',5,'[]'),(62,'CS-39','Caja la plaza de Andres','0','h',5,'[]'),(63,'CS-40','Caja grande ','0','h',5,'[]'),(64,'CS-41','Cono','0','h',5,'[]'),(65,'CS-42','Vasos','0','h',5,'[]'),(66,'CS-43','Farol','0','h',5,'[]'),(67,'CS-44','Caja Arroz','0','h',5,'[]'),(68,'CS-45','Bandeja Conica','0','h',5,'[]'),(69,'CS-46','Plato','0','h',5,'[]'),(70,'CS-47','Caja tipo cono','0','h',5,'[]'),(71,'CS-48','Caja el tambor','0','h',5,'[]'),(72,'CS-49','Porta Hamburguesa','0','h',5,'[]'),(73,'CS-50','Bandeja Papa Francesa','0','h',5,'[]'),(74,'CS-51','Bandeja Carton Corrugado','0','h',5,'[]'),(75,'E-01',' MANIJA','1','<p>a</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',9,'[]');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products_has_materials`
--

DROP TABLE IF EXISTS `products_has_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_has_materials` (
  `products_id_products` int(11) NOT NULL,
  `materials_id_materials` int(11) NOT NULL,
  `minimun_scale` double DEFAULT NULL,
  `medium_scale` double DEFAULT NULL,
  `maximun_scale` double DEFAULT NULL,
  PRIMARY KEY (`products_id_products`,`materials_id_materials`),
  KEY `fk_products_has_materials_materials1_idx` (`materials_id_materials`),
  KEY `fk_products_has_materials_products1_idx` (`products_id_products`),
  CONSTRAINT `fk_products_has_materials_materials1` FOREIGN KEY (`materials_id_materials`) REFERENCES `materials` (`id_materials`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_products_has_materials_products1` FOREIGN KEY (`products_id_products`) REFERENCES `products` (`id_products`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_has_materials`
--

LOCK TABLES `products_has_materials` WRITE;
/*!40000 ALTER TABLE `products_has_materials` DISABLE KEYS */;
INSERT INTO `products_has_materials` (`products_id_products`, `materials_id_materials`, `minimun_scale`, `medium_scale`, `maximun_scale`) VALUES (2,2,NULL,NULL,NULL),(2,7,NULL,NULL,NULL),(2,8,NULL,NULL,NULL),(2,9,NULL,NULL,NULL),(2,10,NULL,NULL,NULL),(2,12,NULL,NULL,NULL),(5,13,3.5,2.5,2),(5,14,3.5,2.5,2),(5,15,4,3,2.5),(5,16,4,3,2),(5,17,4,3,2),(5,18,4,3,2),(5,19,4,3,2),(5,20,4,3,2),(5,21,4,3,2),(5,22,4,3,2),(5,23,4,3,2),(7,43,NULL,NULL,NULL),(8,2,NULL,NULL,NULL),(8,7,NULL,NULL,NULL),(8,8,NULL,NULL,NULL),(8,10,NULL,NULL,NULL),(8,11,NULL,NULL,NULL),(10,24,NULL,NULL,NULL),(10,25,NULL,NULL,NULL),(10,26,NULL,NULL,NULL),(10,27,NULL,NULL,NULL),(11,23,NULL,NULL,NULL),(12,28,NULL,NULL,NULL),(13,29,NULL,NULL,NULL),(14,31,6,5,4),(14,32,6,5,4),(14,33,6,5,4),(14,34,6,5,4),(14,35,6,5,4),(14,36,6,5,4),(14,37,6,5,4),(14,38,6,5,4),(14,39,6,5,4),(14,40,6,5,4),(14,41,6,5,4),(14,42,6,5,4),(15,31,6,5,4),(15,32,6,5,4),(15,33,6,5,4),(15,34,6,5,4),(15,35,6,5,4),(15,36,6,5,4),(15,37,6,5,4),(15,38,6,5,4),(15,39,6,5,4),(15,40,6,5,4),(15,41,6,5,4),(15,42,6,5,4),(16,31,6,5,4),(16,32,6,5,4),(16,33,6,5,4),(16,34,6,5,4),(16,35,6,5,4),(16,36,6,5,4),(16,37,6,5,4),(16,38,6,5,4),(16,39,6,5,4),(16,40,6,5,4),(16,41,6,5,4),(16,42,6,5,4),(17,31,6,5,4),(17,32,6,5,4),(17,33,6,5,4),(17,34,6,5,4),(17,35,6,5,4),(17,36,6,5,4),(17,37,6,5,4),(17,38,6,5,4),(17,39,6,5,4),(17,40,6,5,4),(17,41,6,5,4),(17,42,6,5,4),(18,31,5,4,3.5),(18,32,5,4,3.5),(18,33,5,4,3.5),(18,34,5,4,3.5),(18,35,5,4,3.5),(18,36,5,4,3.5),(18,37,5,4,3.5),(18,38,5,4,3.5),(18,39,5,4,3.5),(18,40,5,4,3.5),(18,41,5,4,3.5),(18,42,5,4,3.5),(19,31,5,4,3.5),(19,32,5,4,3.5),(19,33,5,4,3.5),(19,34,5,4,3.5),(19,35,5,4,3.5),(19,36,5,4,3.5),(19,37,5,4,3.5),(19,38,5,4,3.5),(19,39,5,4,3.5),(19,40,5,4,3.5),(19,41,5,4,3.5),(19,42,5,4,3.5),(20,31,5,4,3.5),(20,32,5,4,3.5),(20,33,5,4,3.5),(20,34,5,4,3.5),(20,35,5,4,3.5),(20,36,5,4,3.5),(20,37,5,4,3.5),(20,38,5,4,3.5),(20,39,5,4,3.5),(20,40,5,4,3.5),(20,41,5,4,3.5),(20,42,5,4,3.5),(21,31,5,4,3.5),(21,32,5,4,3.5),(21,33,5,4,3.5),(21,34,5,4,3.5),(21,35,5,4,3.5),(21,36,5,4,3.5),(21,37,5,4,3.5),(21,38,5,4,3.5),(21,39,5,4,3.5),(21,40,5,4,3.5),(21,41,5,4,3.5),(21,42,5,4,3.5),(22,31,5,4,3.5),(22,32,5,4,3.5),(22,33,5,4,3.5),(22,34,5,4,3.5),(22,35,5,4,3.5),(22,36,5,4,3.5),(22,37,5,4,3.5),(22,38,5,4,3.5),(22,39,5,4,3.5),(22,40,5,4,3.5),(22,41,5,4,3.5),(22,42,5,4,3.5),(23,31,5,4,3.5),(23,32,5,4,3.5),(23,33,5,4,3.5),(23,34,5,4,3.5),(23,35,5,4,3.5),(23,36,5,4,3.5),(23,37,5,4,3.5),(23,38,5,4,3.5),(23,39,5,4,3.5),(23,40,5,4,3.5),(23,41,5,4,3.5),(23,42,5,4,3.5),(24,31,5,4,3.5),(24,32,5,4,3.5),(24,33,5,4,3.5),(24,34,5,4,3.5),(24,35,5,4,3.5),(24,36,5,4,3.5),(24,37,5,4,3.5),(24,38,5,4,3.5),(24,39,5,4,3.5),(24,40,5,4,3.5),(24,41,5,4,3.5),(24,42,5,4,3.5),(25,44,NULL,NULL,NULL),(25,45,NULL,NULL,NULL),(25,46,NULL,NULL,NULL),(25,47,NULL,NULL,NULL),(26,44,NULL,NULL,NULL),(26,45,NULL,NULL,NULL),(26,46,NULL,NULL,NULL),(26,47,NULL,NULL,NULL),(27,44,NULL,NULL,NULL),(27,45,NULL,NULL,NULL),(27,46,NULL,NULL,NULL),(27,47,NULL,NULL,NULL),(28,44,NULL,NULL,NULL),(28,45,NULL,NULL,NULL),(28,46,NULL,NULL,NULL),(28,47,NULL,NULL,NULL),(29,44,NULL,NULL,NULL),(29,45,NULL,NULL,NULL),(29,46,NULL,NULL,NULL),(29,47,NULL,NULL,NULL),(30,44,NULL,NULL,NULL),(30,45,NULL,NULL,NULL),(30,46,NULL,NULL,NULL),(30,47,NULL,NULL,NULL),(31,44,NULL,NULL,NULL),(31,45,NULL,NULL,NULL),(31,46,NULL,NULL,NULL),(31,47,NULL,NULL,NULL),(32,44,NULL,NULL,NULL),(32,45,NULL,NULL,NULL),(32,46,NULL,NULL,NULL),(32,47,NULL,NULL,NULL),(33,44,NULL,NULL,NULL),(33,45,NULL,NULL,NULL),(33,46,NULL,NULL,NULL),(33,47,NULL,NULL,NULL),(34,44,NULL,NULL,NULL),(34,45,NULL,NULL,NULL),(34,46,NULL,NULL,NULL),(34,47,NULL,NULL,NULL),(35,44,NULL,NULL,NULL),(35,45,NULL,NULL,NULL),(35,46,NULL,NULL,NULL),(35,47,NULL,NULL,NULL),(36,44,NULL,NULL,NULL),(36,45,NULL,NULL,NULL),(36,46,NULL,NULL,NULL),(36,47,NULL,NULL,NULL),(37,44,NULL,NULL,NULL),(37,45,NULL,NULL,NULL),(37,46,NULL,NULL,NULL),(37,47,NULL,NULL,NULL),(38,44,NULL,NULL,NULL),(38,45,NULL,NULL,NULL),(38,46,NULL,NULL,NULL),(38,47,NULL,NULL,NULL),(39,44,NULL,NULL,NULL),(39,45,NULL,NULL,NULL),(39,46,NULL,NULL,NULL),(39,47,NULL,NULL,NULL),(40,44,NULL,NULL,NULL),(40,45,NULL,NULL,NULL),(40,46,NULL,NULL,NULL),(40,47,NULL,NULL,NULL),(41,44,NULL,NULL,NULL),(41,45,NULL,NULL,NULL),(41,46,NULL,NULL,NULL),(41,47,NULL,NULL,NULL),(42,44,NULL,NULL,NULL),(42,45,NULL,NULL,NULL),(42,46,NULL,NULL,NULL),(42,47,NULL,NULL,NULL),(43,44,NULL,NULL,NULL),(43,45,NULL,NULL,NULL),(43,46,NULL,NULL,NULL),(43,47,NULL,NULL,NULL),(44,44,NULL,NULL,NULL),(44,45,NULL,NULL,NULL),(44,46,NULL,NULL,NULL),(44,47,NULL,NULL,NULL),(45,44,NULL,NULL,NULL),(45,45,NULL,NULL,NULL),(45,46,NULL,NULL,NULL),(45,47,NULL,NULL,NULL),(46,44,NULL,NULL,NULL),(46,45,NULL,NULL,NULL),(46,46,NULL,NULL,NULL),(46,47,NULL,NULL,NULL),(47,44,NULL,NULL,NULL),(47,45,NULL,NULL,NULL),(47,46,NULL,NULL,NULL),(47,47,NULL,NULL,NULL),(48,44,NULL,NULL,NULL),(48,45,NULL,NULL,NULL),(48,46,NULL,NULL,NULL),(48,47,NULL,NULL,NULL),(49,44,NULL,NULL,NULL),(49,45,NULL,NULL,NULL),(49,46,NULL,NULL,NULL),(49,47,NULL,NULL,NULL),(50,44,NULL,NULL,NULL),(50,45,NULL,NULL,NULL),(50,46,NULL,NULL,NULL),(50,47,NULL,NULL,NULL),(51,44,NULL,NULL,NULL),(51,45,NULL,NULL,NULL),(51,46,NULL,NULL,NULL),(51,47,NULL,NULL,NULL),(52,44,NULL,NULL,NULL),(52,45,NULL,NULL,NULL),(52,46,NULL,NULL,NULL),(52,47,NULL,NULL,NULL),(53,44,NULL,NULL,NULL),(53,45,NULL,NULL,NULL),(53,46,NULL,NULL,NULL),(53,47,NULL,NULL,NULL),(54,44,NULL,NULL,NULL),(54,45,NULL,NULL,NULL),(54,46,NULL,NULL,NULL),(54,47,NULL,NULL,NULL),(55,44,NULL,NULL,NULL),(55,45,NULL,NULL,NULL),(55,46,NULL,NULL,NULL),(55,47,NULL,NULL,NULL),(56,44,NULL,NULL,NULL),(56,45,NULL,NULL,NULL),(56,46,NULL,NULL,NULL),(56,47,NULL,NULL,NULL),(57,44,NULL,NULL,NULL),(57,45,NULL,NULL,NULL),(57,46,NULL,NULL,NULL),(57,47,NULL,NULL,NULL),(58,44,NULL,NULL,NULL),(58,45,NULL,NULL,NULL),(58,46,NULL,NULL,NULL),(58,47,NULL,NULL,NULL),(59,44,NULL,NULL,NULL),(59,45,NULL,NULL,NULL),(59,46,NULL,NULL,NULL),(59,47,NULL,NULL,NULL),(60,44,NULL,NULL,NULL),(60,45,NULL,NULL,NULL),(60,46,NULL,NULL,NULL),(60,47,NULL,NULL,NULL),(61,44,NULL,NULL,NULL),(61,45,NULL,NULL,NULL),(61,46,NULL,NULL,NULL),(61,47,NULL,NULL,NULL),(62,44,NULL,NULL,NULL),(62,45,NULL,NULL,NULL),(62,46,NULL,NULL,NULL),(62,47,NULL,NULL,NULL),(63,44,NULL,NULL,NULL),(63,45,NULL,NULL,NULL),(63,46,NULL,NULL,NULL),(63,47,NULL,NULL,NULL),(64,44,NULL,NULL,NULL),(64,45,NULL,NULL,NULL),(64,46,NULL,NULL,NULL),(64,47,NULL,NULL,NULL),(65,44,NULL,NULL,NULL),(65,45,NULL,NULL,NULL),(65,46,NULL,NULL,NULL),(65,47,NULL,NULL,NULL),(66,44,NULL,NULL,NULL),(66,45,NULL,NULL,NULL),(66,46,NULL,NULL,NULL),(66,47,NULL,NULL,NULL),(67,44,NULL,NULL,NULL),(67,45,NULL,NULL,NULL),(67,46,NULL,NULL,NULL),(67,47,NULL,NULL,NULL),(68,44,NULL,NULL,NULL),(68,45,NULL,NULL,NULL),(68,46,NULL,NULL,NULL),(68,47,NULL,NULL,NULL),(69,44,NULL,NULL,NULL),(69,45,NULL,NULL,NULL),(69,46,NULL,NULL,NULL),(69,47,NULL,NULL,NULL),(70,44,NULL,NULL,NULL),(70,45,NULL,NULL,NULL),(70,46,NULL,NULL,NULL),(70,47,NULL,NULL,NULL),(71,44,NULL,NULL,NULL),(71,45,NULL,NULL,NULL),(71,46,NULL,NULL,NULL),(71,47,NULL,NULL,NULL),(72,44,NULL,NULL,NULL),(72,45,NULL,NULL,NULL),(72,46,NULL,NULL,NULL),(72,47,NULL,NULL,NULL),(73,44,NULL,NULL,NULL),(73,45,NULL,NULL,NULL),(73,46,NULL,NULL,NULL),(73,47,NULL,NULL,NULL),(74,44,NULL,NULL,NULL),(74,45,NULL,NULL,NULL),(74,46,NULL,NULL,NULL),(74,47,NULL,NULL,NULL);
/*!40000 ALTER TABLE `products_has_materials` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`sotechco`@`localhost`*/ /*!50003 TRIGGER `borrado_medidas` AFTER DELETE ON `products_has_materials` FOR EACH ROW DELETE FROM `measurements` WHERE `measurements`.`id_material` = OLD.materials_id_materials AND `measurements`.`products_id_products` = OLD.products_id_products */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `products_tabs`
--

DROP TABLE IF EXISTS `products_tabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products_tabs` (
  `id_tab` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8_spanish_ci NOT NULL,
  `description` text COLLATE utf8_spanish_ci NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id_tab`),
  KEY `fk_product_tabs_products` (`product_id`),
  CONSTRAINT `fk_product_tabs_products` FOREIGN KEY (`product_id`) REFERENCES `products` (`id_products`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products_tabs`
--

LOCK TABLES `products_tabs` WRITE;
/*!40000 ALTER TABLE `products_tabs` DISABLE KEYS */;
INSERT INTO `products_tabs` (`id_tab`, `title`, `description`, `product_id`) VALUES (1,'Caracteristicas','<p><strong>Bolsas que poseen fuelles laterales y base.</strong></p><p>Especiales para productos con volumen. Nuestras bolsas tipo AUTOM&Aacute;TICA, se elaboran en m&aacute;quina con impresi&oacute;n exoagua.</p><p>En caso de usarlas para domicilios de comida, ayudan a la buena conservaci&oacute;n del estado natural del alimento evitando la condensaci&oacute;n de humedad dentro del empaque.</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',5),(2,'Especificaciones','<p><strong>Materiales</strong></p><ul><li><strong>Papel:</strong> Antigrasa, Bond, Earth pact, y Kraft</li><li><strong>Impresi&oacute;n:</strong> Flexoagua</li><li><strong>Gramaje:</strong> De 60 a 170g</li><li><strong>Capacidad:</strong> Desde 1 kg hasta 25 kg seg&uacute;n vol&uacute;men.</li></ul><p>__________________________________________________________________________________________________________</p><p><strong>Medidas</strong></p><ul><li><strong>Ancho</strong>: Desde 10 cm hasta 49 cms.</li><li><strong>Fuelle</strong>: Desde 8 cm hasta 22 cm.</li><li><strong>Largo total</strong>: Desde 32 cm hasta 92 cm</li><li><strong>Gramaje</strong>: Desde 60 grs hasta 200 grs</li><li><strong>Capas</strong>: desde 1 hasta 2</li></ul><p><img src=\"https://en.teenus.com.co/upload/img/IMG-1565909822-5d55e33e115e0.png\" style=\"width: 300px;\" class=\"fr-fic fr-dib\"></p><p>__________________________________________________________________________________________________________</p><p><strong>Opcional:</strong></p><ul><li><strong>Ventanilla:</strong> En PLA (&Aacute;cido Poli l&aacute;ctico a base de ma&iacute;z), que permiten la exhibici&oacute;n del producto.</li><li><strong>Medida de la ventanilla:</strong> Desde 2 hasta 27 cms. conservando margen m&iacute;nimo de 3 cm de papel a cada lado.</li><li><strong>Impresi&oacute;n:</strong> hasta 4 tintas desde 10.000 unidades.</li><li><strong>Manijas:</strong> Troquelada, Refuerzo en cart&oacute;n, Trenzada En papel, Cord&oacute;n trenzado, Cintas, Cordones.</li><li><strong>Refuerzos de cart&oacute;n:</strong> en solapa y/o base.</li></ul><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',5),(3,'Caracteristicas','<ol><li>Permite la &nbsp;exhibici&oacute;n del producto.</li><li>Protecci&oacute;n.</li><li>Preservaci&oacute;n &nbsp;de &nbsp;frutas y semillas de los &nbsp;rayos solares y plagas.</li><li>Reduciendo la aspersi&oacute;n &nbsp;de pesticidas &nbsp;para la protecci&oacute;n de estas.</li><li>Protege la intemperie.</li></ol><p><br></p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',2),(4,'Especificaciones','<p><strong>Se elaboran en:</strong></p><ul><li><strong>Papeles: &nbsp;</strong>FineKraft , MG Blanco, MG Natural, Bond y Antigrasa</li><li><strong>Gramaje:</strong> Entre 35g y 60g.</li></ul><p>____________________________________________________________________________________________</p><p><strong>Medidas:</strong></p><ul><li><strong>Ancho:</strong> Desde 7 hasta 30 cms.</li><li><strong>Fuelle:</strong> Desde 4,5 hasta 15 cm.</li><li><strong>Largo total:</strong> Desde 12 hasta 70 cm</li><li><strong>Capacidad:</strong> desde 1/2 libra hasta 25 libras.<img src=\"https://en.teenus.com.co/upload/img/IMG-1565908477-5d55ddfd534d7.png\" style=\"width: 300px;\" class=\"fr-fic fr-dib\"></li></ul><p>______________________________________________________________________________________________________</p><p><strong>Opcional:</strong></p><ul><li><strong>Ventanilla:</strong> que permiten la exhibici&oacute;n del producto. Hecho en PLA (&Aacute;cido Polil&aacute;ctico a base de ma&iacute;z),&nbsp;</li><li><strong>Medida de la ventanilla:</strong> Desde 2 hasta 27 cms. conservando margen m&iacute;nimo de 3 cm de papel a cada lado.</li><li><strong>Impresi&oacute;n:</strong> hasta 4 tintas desde 10.000 unidades.</li></ul><p><br></p><p style=\"text-align: center;\"><strong><em><u>MATERIALES TOTALMENTE BIODEGRADABLES</u></em></strong></p><p><br></p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',2),(5,'Caracteristicas','<ol><li>Barrera a los rayos de luz, ox&iacute;geno, humedad y agentes externos.</li><li>Garantiza la calidad del producto.</li><li>El &nbsp;aroma se conserve &nbsp;especialmente para caf&eacute;s artesanales, org&aacute;nicos, t&eacute; y arom&aacute;ticas.</li></ol><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',3),(6,'Especificaciones','<p><strong>Caracteristicas</strong></p><ul><li><strong>Papel:</strong> Kraft, Bond, Earth pact</li><li><strong>Gramajes:</strong> Entre 60g y 170g.</li><li><strong>Capacidad:</strong> desde 30 g. hasta 5 Kg.</li><li><strong>Impresi&oacute;n</strong>: hasta 4 tintas tipo offset ( tintas base soya).</li></ul><p><strong>Opcional:</strong></p><ul><li><strong>Cierre ecol&oacute;gico</strong>: elaborado en alambre pre-oxidado y laminado en kraft. (de 1 a 3 alambres).</li><li><strong>V&aacute;lvulas desgasificadoras:</strong> adhesivas, permitiendo un cierre herm&eacute;tico del empaque para conservar el producto.</li><li><strong>Laminado:</strong> PLA (&Aacute;cido Polil&aacute;ctico, pl&aacute;stico a base de ma&iacute;z), metalizado opcional con aluminio aspersado a 0.2g/m haciendo barrera a los rayos de luz, ox&iacute;geno, humedad y agentes externos, garantizando la calidad del producto.</li><li><strong>Troquelado:</strong> para exhibir o colgar</li><li><strong>Ventanilla:</strong> En PLA (&Aacute;cido Polil&aacute;ctico a base de ma&iacute;z), que permiten la exhibici&oacute;n del producto, con formatos diferentes: Troquelada centrada o de lado a lado vertical. &Uacute;NICAMENTE PARA LAS BOLSAS QUE TIENE LAMINACI&Oacute;N PLA.</li></ul><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',3),(7,'Caracteristicas','<p><strong>Estas Bolsas carecen de fuelles Laterales (tipo sobre).</strong></p><ol><li>Resistente a la grasa</li><li>Resistente a la temperatura alta</li><li>Conserva la temperatura del producto</li><li>Material alto para la preservar los alimentos</li></ol><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8),(8,'Especificaciones','<p><strong>Especificaciones:</strong></p><ul><li><strong>Papeles:</strong> FineKraft , MG Blanco, MG Natural, bond y antigrasa.</li><li><strong>Gramaje:</strong> Entre 40g y 60g.</li></ul><p>_______________________________________________________________________________________________</p><p><strong>Medidas:</strong></p><ul><li><strong>Ancho:</strong> Desde 7cms hasta 17 cms.</li><li><strong>Largo total:</strong> Desde 12 cms hasta 38 cms</li><li><strong>Capacidad:</strong> desde 1/2 libra hasta 25 libras.</li></ul><p>_______________________________________________________________________________________________</p><p><strong>Opcional:</strong></p><ul><li><strong>Laminada:</strong> En PLA (&Aacute;cido Poli l&aacute;ctico a base de ma&iacute;z) transparente o metalizado, seg&uacute;n sea el producto.</li><li><strong>Ventanilla:</strong> En PLA (&Aacute;cido Poli l&aacute;ctico a base de ma&iacute;z), que permiten la exhibici&oacute;n del producto.</li><li><strong>Medida de la ventanilla:</strong> Desde 2 hasta 27 cms. conservando margen m&iacute;nimo de 3 cm de papel a cada lado.</li><li><strong>Impresi&oacute;n:</strong> hasta 4 tintas desde 10.000 unidades.</li></ul><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',8),(9,'Beneficios','<ol><li>&nbsp; &nbsp; Medio de Comunicacion responsable</li><li>&nbsp; &nbsp;Segura para los ni&ntilde;os y animales</li><li>&nbsp; &nbsp; Posibilidad de ventanilla para mostrar sus productos</li><li>&nbsp; &nbsp; Menor tiempo de empaque</li><li>&nbsp; &nbsp; Facil de apilar<img src=\"https://en.teenus.com.co/upload/img/IMG-1565908964-5d55dfe4de37b.png\" style=\"width: 147px;\" class=\"fr-fic fr-fil fr-shadow fr-dib\"></li></ol><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',2),(10,'Características Generales','<p>Protegen tu producto desde la preparaci&oacute;n hasta el consumo. Estos papeles son de diversos gramajes, resistentes a la humedad y a la grasa, permiten que lleguen al consumidor final en un excelente estado. A diferencia de otros materiales, no est&aacute;n parafinados ni encerados, resisten altas y bajas temperaturas, se pueden calentar en horno convencional o microondas, no son t&oacute;xicos y son 100% biodegradables.</p><p>&nbsp;</p><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',10),(11,'Características específicas ','<ul><li><strong>Material:</strong> Earth pact &ndash; fine kraft &ndash; kraft</li><li><strong>Impresi&oacute;n:</strong> Litogr&aacute;fica en tintas a base de soya</li><li><strong>Gramaje:</strong> 40 gr a 85 gr</li><li><strong>Cantidad m&iacute;nima:</strong>&nbsp; 3.000</li></ul><p data-f-id=\"pbf\" style=\"text-align: center; font-size: 14px; margin-top: 30px; opacity: 0.65; font-family: sans-serif;\">Powered by <a href=\"https://www.froala.com/wysiwyg-editor?pb=1\" title=\"Froala Editor\">Froala Editor</a></p>',10);
/*!40000 ALTER TABLE `products_tabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotations`
--

DROP TABLE IF EXISTS `quotations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotations` (
  `id_quotations` int(11) NOT NULL AUTO_INCREMENT,
  `city` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `address` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `cell_phone` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_spanish_ci,
  `file` varchar(512) CHARACTER SET utf8 COLLATE utf8_spanish_ci DEFAULT NULL,
  `payment_conditions` varchar(512) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '50% contra pedido - 50% contra facturación para entrega',
  `delivery_time` varchar(512) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT 'Sin impresion 8 dias - impresos 15 dias',
  `validity` varchar(512) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT '30 dias contados a partir de la fecha de la entrega de la cotización presente propuesta',
  `id_admin_assignment` int(11) DEFAULT NULL,
  `date_assignment` timestamp NULL DEFAULT NULL,
  `solved` tinyint(1) NOT NULL DEFAULT '0',
  `clients_id_clients` int(11) NOT NULL,
  `date_solved` timestamp NULL DEFAULT NULL,
  `id_admin_solved` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_quotations`,`clients_id_clients`),
  KEY `fk_quotations_clients1_idx` (`clients_id_clients`),
  CONSTRAINT `fk_quotations_clients1` FOREIGN KEY (`clients_id_clients`) REFERENCES `clients` (`id_clients`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotations`
--

LOCK TABLES `quotations` WRITE;
/*!40000 ALTER TABLE `quotations` DISABLE KEYS */;
INSERT INTO `quotations` (`id_quotations`, `city`, `address`, `cell_phone`, `phone`, `description`, `file`, `payment_conditions`, `delivery_time`, `validity`, `id_admin_assignment`, `date_assignment`, `solved`, `clients_id_clients`, `date_solved`, `id_admin_solved`, `created_at`) VALUES (1,'Bogota','Carrera 77 b bis a #75a - 14','3222724734','','','','50% contra pedido - 50% contra facturación para entrega','Sin impresion 8 dias - impresos 15 dias','30 dias contados a partir de la fecha de la entrega de la cotización presente propuesta',7,'2019-12-06 15:23:40',0,1,'0000-00-00 00:00:00',NULL,'2019-12-06 15:23:41'),(2,'','','','','','','50% contra pedido - 50% contra facturación para entrega','Sin impresion 8 dias - impresos 15 dias','30 dias contados a partir de la fecha de la entrega de la cotización presente propuesta',7,'2019-12-06 15:26:47',0,2,NULL,NULL,'2019-12-06 15:26:48'),(3,'Bogota','Carrera 77 b bis a #75a - 14','3222724734','','','','50% contra pedido - 50% contra facturación para entrega','Sin impresion 8 dias - impresos 15 dias','30 dias contados a partir de la fecha de la entrega de la cotización presente propuesta',7,'2019-12-06 15:51:57',0,1,'0000-00-00 00:00:00',NULL,'2019-12-06 15:51:58');
/*!40000 ALTER TABLE `quotations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quotations_details`
--

DROP TABLE IF EXISTS `quotations_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quotations_details` (
  `id_quotations_details` int(11) NOT NULL AUTO_INCREMENT,
  `products_id_products` int(11) NOT NULL,
  `quantity` bigint(40) DEFAULT NULL,
  `printed` tinyint(1) NOT NULL,
  `laminated` tinyint(1) NOT NULL,
  `pla` tinyint(1) NOT NULL,
  `price` bigint(20) NOT NULL,
  `observations` text,
  `number_inks` int(11) DEFAULT NULL,
  `type_product` varchar(256) DEFAULT NULL,
  `material_id` int(11) DEFAULT NULL,
  `measurement_id` int(11) DEFAULT NULL,
  `quotations_id_quotations` int(11) NOT NULL,
  PRIMARY KEY (`id_quotations_details`,`products_id_products`,`quotations_id_quotations`) USING BTREE,
  KEY `fk_quotations_details_products1_idx` (`products_id_products`),
  KEY `fk_quotations_details_quotations1_idx` (`quotations_id_quotations`),
  KEY `fk_quotations_details_materials1` (`material_id`),
  KEY `fk_quotations_details_measurements1` (`measurement_id`),
  CONSTRAINT `fk_material_quotations_details` FOREIGN KEY (`material_id`) REFERENCES `materials` (`id_materials`) ON DELETE SET NULL,
  CONSTRAINT `fk_measurement_quotations_details` FOREIGN KEY (`measurement_id`) REFERENCES `measurements` (`id_measurements`) ON DELETE SET NULL,
  CONSTRAINT `fk_quotations_details_products1` FOREIGN KEY (`products_id_products`) REFERENCES `products` (`id_products`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_quotations_details_quotations1` FOREIGN KEY (`quotations_id_quotations`) REFERENCES `quotations` (`id_quotations`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quotations_details`
--

LOCK TABLES `quotations_details` WRITE;
/*!40000 ALTER TABLE `quotations_details` DISABLE KEYS */;
INSERT INTO `quotations_details` (`id_quotations_details`, `products_id_products`, `quantity`, `printed`, `laminated`, `pla`, `price`, `observations`, `number_inks`, `type_product`, `material_id`, `measurement_id`, `quotations_id_quotations`) VALUES (1,25,2000,1,0,0,450,'',2,'Productos Humedos',46,269,1),(2,25,2002,1,0,0,367,'',2,'Productos Humedos',44,269,3),(3,31,1000,1,0,0,183,'',3,'Productos Grasos',44,290,3),(4,14,2994,1,0,0,780,'',NULL,'',41,153,3),(6,7,3000,1,0,0,452,'',NULL,'Productos Secos',43,243,3),(7,2,20000,1,1,1,113,NULL,NULL,NULL,2,1357,3),(8,10,5000,1,0,0,27,'',NULL,'Productos Secos',24,1401,3),(9,11,5000,1,0,0,129,'',NULL,'Productos Secos',23,135,3),(10,13,5000,1,0,0,14,'',NULL,'Productos Secos',29,149,3);
/*!40000 ALTER TABLE `quotations_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles_admin`
--

DROP TABLE IF EXISTS `roles_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles_admin` (
  `id_role` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles_admin`
--

LOCK TABLES `roles_admin` WRITE;
/*!40000 ALTER TABLE `roles_admin` DISABLE KEYS */;
INSERT INTO `roles_admin` (`id_role`, `name`) VALUES (1,'vendedor'),(2,'administrador'),(3,'community manager');
/*!40000 ALTER TABLE `roles_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slides_banner`
--

DROP TABLE IF EXISTS `slides_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slides_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` text COLLATE utf8_spanish_ci NOT NULL,
  `header` text COLLATE utf8_spanish_ci NOT NULL,
  `title` text COLLATE utf8_spanish_ci NOT NULL,
  `subtitle` text COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slides_banner`
--

LOCK TABLES `slides_banner` WRITE;
/*!40000 ALTER TABLE `slides_banner` DISABLE KEYS */;
INSERT INTO `slides_banner` (`id`, `image`, `header`, `title`, `subtitle`) VALUES (1,'/images/AdobeStock_114530769_Preview.jpeg','Descubre la magia de nuestros empaques','Exportación','Diseñamos tus empaques especiales para tus productos de exportación.'),(2,'/images/AdobeStock_178732916_Preview.jpeg','Descubre la magia de nuestros empaques','Innovación','El comienzo de una nueva era para llevar, servir y exhibir.'),(5,'/images/beach.jpg','¿Qué tipo de empaque quieres tener?','100% Biodegradable','Empaques desarrollados para que ayudemos al planeta.');
/*!40000 ALTER TABLE `slides_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suscribers`
--

DROP TABLE IF EXISTS `suscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suscribers` (
  `id_suscriber` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id_suscriber`),
  UNIQUE KEY `unique_email_suscriber` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suscribers`
--

LOCK TABLES `suscribers` WRITE;
/*!40000 ALTER TABLE `suscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `suscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sotechco_greenpack'
--

--
-- Dumping routines for database 'sotechco_greenpack'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-02  8:53:15
